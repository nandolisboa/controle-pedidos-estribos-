import React, { useEffect } from 'react';
import { Printer, X } from 'lucide-react';
import type { Pedido } from '../types';
import {
  compararItensMLivre,
  dataEntradaDoPedido,
  dataPedidoPronto,
  embalagemDoItem,
  fmtDataHora,
  fmtQtd,
  formatarDataISO,
  infoTelaDoItem,
  pacotesDe,
  textoQtdOutro,
} from '../utils';

interface PrintSheetProps {
  pedidos: Pedido[];
  titulo: string;
  emittedAt?: number;
}

const PrintDocumentBody: React.FC<PrintSheetProps> = ({ pedidos, titulo, emittedAt }) => {
  const dataHoraEmissao = fmtDataHora(emittedAt || Date.now());

  return (
    <>
      <div className="pdf-header">
        <div className="pdf-header-left">
          <div className="pdf-brand">
            ARAMES <span>BRASIL</span>
          </div>
          <span className="pdf-title">{titulo}</span>
        </div>
        <div className="pdf-sub">Emissão: {dataHoraEmissao}</div>
      </div>

    {pedidos.map((p, index) => {
      const diaPronto = p.pronto && !p.entregue ? dataPedidoPronto(p) : null;
      const anterior = pedidos[index - 1];
      const mostrarDia = pedidos.length > 1 && diaPronto && (!anterior || !anterior.pronto || anterior.entregue || dataPedidoPronto(anterior) !== diaPronto);
      const entrada = formatarDataISO(dataEntradaDoPedido(p));
      const entregaText =
        p.mLivre && p.entregaMLivre
          ? ` · Hora limite: ${p.entregaMLivre}`
          : p.pretensaoEntrega
          ? ` · Entrega: ${formatarDataISO(p.pretensaoEntrega)}`
          : '';

      const itensExibidos = p.itens.map((item, idx) => ({ item, idx }));
      if (p.mLivre) itensExibidos.sort((a, b) => compararItensMLivre(a.item, b.item) || a.idx - b.idx);

      return (
        <React.Fragment key={p.id}>
        {mostrarDia && <div style={{ fontWeight: 'bold', margin: '12px 0 6px' }}>Prontos em {formatarDataISO(diaPronto)}{pedidos.some((pedido) => pedido.pronto && !pedido.entregue && dataPedidoPronto(pedido) === diaPronto && !(Number(pedido.prontoEm) > 0)) ? ' (antigos sem conclusão: data de entrada)' : ''}</div>}
        <div className={`pdf-pedido ${p.urgente ? 'urgente' : ''}`}>
          <div className="pdf-pedido-top">
            <div className="pdf-pedido-ident">
              <span className="pdf-cliente">{p.cliente}</span>
              {p.mLivre ? (
                <span className="pdf-urgente">★ M.LIVRE · PRIORIDADE</span>
              ) : p.urgente ? (
                <span className="pdf-urgente">URGENTE</span>
              ) : null}
            </div>
            <span className="pdf-data">
              Entrada: {entrada}
              {entregaText}
            </span>
          </div>

          <table className="pdf-tab">
            <thead>
              <tr>
                <th>Medida</th>
                <th>Material</th>
                <th className="num">{p.mLivre ? 'Estribos' : 'Qtd'}</th>
                <th className="num">{p.mLivre ? 'Embalagem' : 'Pacotes'}</th>
                <th>KG</th>
              </tr>
            </thead>
            <tbody>
              {itensExibidos.map(({ item: i, idx }) => {
                const tela = infoTelaDoItem(i);
                const emb = i.tipo !== 'outro' ? embalagemDoItem(i, p.mLivre) : null;
                return (
                  <tr key={idx}>
                    <td>{i.tipo === 'outro' ? tela?.medida || i.medida || '—' : i.medida}</td>
                    <td>
                      {i.tipo === 'outro'
                        ? tela
                          ? `${tela.codigo} · ${tela.bitola}`
                          : i.codigo
                          ? `${i.codigo} · ${i.bitola}`
                          : i.material
                        : `${i.material} mm`}
                    </td>
                    <td className="num">
                      {i.tipo === 'outro'
                        ? textoQtdOutro(i)
                        : p.mLivre
                        ? `${fmtQtd(i.qtd)} estribos`
                        : fmtQtd(i.qtd)}
                    </td>
                    <td className="num">
                      {p.mLivre
                        ? `${emb === 'caixa' ? 'Cx ' : ''}${i.caixaNumero || idx + 1}`
                        : i.tipo !== 'outro'
                        ? emb === 'caixa'
                          ? 'Caixa'
                          : `${pacotesDe(i.qtd)}`
                        : ''}
                    </td>
                    <td>
                      {i.tipo !== 'outro' && Number(p.pesoKgPorItem?.[String(idx)]) > 0
                        ? `${Number(p.pesoKgPorItem[String(idx)]).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} kg`
                        : <span className="pdf-kg-linha">&nbsp;</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {p.obs && (
            <div className="pdf-info">
              <b>Anotações:</b> {p.obs}
            </div>
          )}

          <div className="pdf-informacoes">
            <span>Informações:</span>
            <span className="pdf-informacoes-linha" />
          </div>
        </div>
        </React.Fragment>
      );
    })}
    </>
  );
};

export const PrintSheet: React.FC<PrintSheetProps> = ({ pedidos, titulo, emittedAt }) => {
  if (!pedidos.length) return <div id="printArea" />;

  return (
    <div id="printArea">
      <PrintDocumentBody pedidos={pedidos} titulo={titulo} emittedAt={emittedAt} />
    </div>
  );
};

interface PdfPreviewModalProps {
  open: boolean;
  pedidos: Pedido[];
  titulo: string;
  emittedAt?: number;
  onClose: () => void;
  onPrint: () => void;
}

export const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({
  open,
  pedidos,
  titulo,
  emittedAt,
  onClose,
  onPrint,
}) => {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open || !pedidos.length) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Prévia do PDF: ${titulo}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-3 sm:p-6"
    >
      <div className="w-full max-w-4xl max-h-[92vh] bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
        <div className="px-4 py-3 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 truncate">
              Prévia do PDF · {titulo}
            </h2>
            <p className="text-xs text-slate-500">
              Visualização em formato A4 antes de imprimir ou salvar
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onPrint}
              className="min-h-[40px] px-4 py-2 inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Imprimir / Salvar PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Fechar prévia do PDF"
              className="min-h-[40px] px-3 py-2 inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
              Fechar
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto bg-slate-200/80 p-3 sm:p-6">
          <div className="pdf-sheet w-full max-w-[794px] mx-auto bg-white border border-slate-300 shadow-md p-6 sm:p-9">
            <PrintDocumentBody pedidos={pedidos} titulo={titulo} emittedAt={emittedAt} />
          </div>
        </div>
      </div>
    </div>
  );
};
