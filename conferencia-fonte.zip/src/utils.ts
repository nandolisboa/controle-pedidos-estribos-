import type { EmbalagemTipo, Pedido, PedidoItem, StatusFiltro, TelaSpec } from './types';

export const PECAS_POR_PACOTE = 500;
export const MATERIAIS = ['3.8', '4.2', '5.0', '6.0'] as const;

export const TELAS: TelaSpec[] = [
  { codigo: 'Q138 / EQ138', medida: '10 × 10 cm', bitola: '4,2 mm' },
  { codigo: 'Q61 / EQ61', medida: '15 × 15 cm', bitola: '3,4 mm' },
  { codigo: 'Q92 / EQ92', medida: '15 × 15 cm', bitola: '4,2 mm' },
  { codigo: 'Q45 / EQ45', medida: '20 × 20 cm', bitola: '3,4 mm' },
];

export function telaPorCodigo(valor: string): TelaSpec | null {
  const texto = String(valor || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!texto) return null;
  return (
    TELAS.find((tela) =>
      tela.codigo.split('/').some((alias) => {
        const chave = alias.replace(/[^A-Z0-9]/g, '');
        return chave && (texto === chave || texto.includes(chave));
      })
    ) || null
  );
}

export function infoTelaDoItem(item: PedidoItem | null | undefined): TelaSpec | null {
  if (!item || item.tipo !== 'outro') return null;
  const codigoSalvo = String(item.codigo || item.material || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const tela = TELAS.find((opcao) =>
    opcao.codigo.split('/').some((alias) => {
      const chave = alias.replace(/[^A-Z0-9]/g, '');
      return chave && codigoSalvo.includes(chave);
    })
  );
  const ehTela =
    String(item.material || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .includes('tela') || !!tela;
  if (!ehTela || !tela) return null;
  const medidaSalva = String(item.medida || '').trim();
  return {
    codigo: tela.codigo,
    medida: !medidaSalva || medidaSalva === '—' ? tela.medida : medidaSalva,
    bitola: item.bitola || tela.bitola,
  };
}

export function tipoMaterialOutro(nome: string): 'arame' | 'tela' | 'barra' | 'bobina' | 'generico' {
  const n = String(nome || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
  if (n.includes('arame')) return 'arame';
  if (n.includes('tela') || telaPorCodigo(nome)) return 'tela';
  if (n.includes('barra')) return 'barra';
  if (n.includes('bobina')) return 'bobina';
  return 'generico';
}

export function bitolaClass(material: string): string {
  const normalizada = String(material ?? '').trim().replace(',', '.');
  switch (normalizada) {
    case '3.8':
      return 'text-blue-700';
    case '4.2':
      return 'text-emerald-700';
    case '5.0':
      return 'text-amber-700';
    case '6.0':
      return 'text-violet-700';
    default:
      return 'text-slate-700';
  }
}

export function fmtQtd(n: number): string {
  return Number(n || 0).toLocaleString('pt-BR');
}

export function fmtKg(n: number): string {
  return Number(n || 0).toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function lerQuantidade(texto: string): number {
  const valor = String(texto ?? '').trim().replace(',', '.');
  if (!/^\d+(\.\d+)?$/.test(valor)) return NaN;
  return Number(valor);
}

export function textoQtdOutro(item: PedidoItem): string {
  const qtd = item.unidade === 'kg' ? fmtKg(item.qtd) : fmtQtd(item.qtd);
  const unidade = item.unidade === 'kg' ? 'kg' : 'un.';
  const caixas = item.caixas ? ` · ${fmtQtd(item.caixas)} cx` : '';
  const rolo =
    item.unidade === 'kg' && !item.caixas && !item.naoCaixa && tipoMaterialOutro(item.material) === 'arame'
      ? ' · rolo'
      : '';
  return `${qtd} ${unidade}${caixas}${rolo}`;
}

export function pacotesDe(qtd: number): number {
  const valor = Number(qtd) || 0;
  if (valor <= 0) return 0;
  return Math.ceil(valor / PECAS_POR_PACOTE);
}

export function embalagemDoItem(item: PedidoItem, mLivre = false): EmbalagemTipo {
  if (!mLivre) return 'pacote';
  if (item.embalagem === 'caixa' || item.embalagem === 'pacote') return item.embalagem;
  return 'caixa';
}

export function dataLocalISO(data = new Date()): string {
  const ano = data.getFullYear();
  const mes = String(data.getMonth() + 1).padStart(2, '0');
  const dia = String(data.getDate()).padStart(2, '0');
  return `${ano}-${mes}-${dia}`;
}

export function formatarDataISO(valor: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(valor || ''));
  if (!match) return '—';
  const [, ano, mes, dia] = match;
  const data = new Date(Date.UTC(Number(ano), Number(mes) - 1, Number(dia)));
  if (
    Number.isNaN(data.getTime()) ||
    data.getUTCFullYear() !== Number(ano) ||
    data.getUTCMonth() + 1 !== Number(mes) ||
    data.getUTCDate() !== Number(dia)
  ) {
    return '—';
  }
  return `${dia}/${mes}/${ano}`;
}

export function dataEntradaDoPedido(pedido: Pick<Pedido, 'dataEntrada' | 'criadoEm'>): string {
  if (pedido.dataEntrada) return pedido.dataEntrada;
  return pedido.criadoEm ? dataLocalISO(new Date(pedido.criadoEm)) : dataLocalISO();
}

export function fmtDataHora(ts?: number | null): string {
  const instante = Number(ts);
  if (!Number.isFinite(instante) || instante <= 0) return '—';
  const d = new Date(instante);
  if (Number.isNaN(d.getTime())) return '—';
  return (
    d.toLocaleDateString('pt-BR') +
    ' ' +
    d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  );
}

export function statusPedido(p: Pedido): 'entregue' | 'pronto' | 'urgente' | 'produzindo' {
  if (p.entregue) return 'entregue';
  if (p.pronto) return 'pronto';
  if (p.urgente) return 'urgente';
  return 'produzindo';
}

export function ordenarPedidos(lista: Pedido[]): Pedido[] {
  return [...lista].sort((a, b) => {
    if (a.urgente !== b.urgente) return a.urgente ? -1 : 1;
    return (a.criadoEm || 0) - (b.criadoEm || 0);
  });
}

export function filtrarPedidos(lista: Pedido[], busca: string, status: StatusFiltro): Pedido[] {
  const termo = normalizarBusca(busca);
  if (!termo && status === 'todos') return lista;
  return lista.filter((p) => {
    const statusMatch =
      status === 'todos' ||
      statusPedido(p) === status ||
      (status === 'produzindo' && p.urgente && !p.pronto && !p.entregue);
    if (!statusMatch) return false;
    if (!termo) return true;
    if (normalizarBusca(p.cliente).includes(termo)) return true;
    return p.itens.some(
      (i) =>
        normalizarBusca(i.medida).includes(termo) ||
        normalizarBusca(i.material).includes(termo) ||
        normalizarBusca(i.codigo || '').includes(termo)
    );
  });
}

export function normalizarBusca(valor: string): string {
  return String(valor || '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('pt-BR');
}

export function escHtml(s: string): string {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));
}
