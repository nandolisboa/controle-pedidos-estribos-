import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Plus, X } from 'lucide-react';
import type { EmbalagemTipo, ItemTipo, Pedido, PedidoItem, UnidadeOutro } from '../types';
import {
  MATERIAIS,
  bitolaClass,
  dataLocalISO,
  embalagemDoItem,
  fmtQtd,
  lerQuantidade,
  normalizarBusca,
  pacotesDe,
  telaPorCodigo,
  textoQtdOutro,
  tipoMaterialOutro,
} from '../utils';

export interface DraftOrderPayload {
  editingId: string | null;
  mLivre: boolean;
  cliente: string;
  dataEntrada: string;
  pretensaoEntrega: string;
  entregaMLivreHora: string;
  urgente: boolean;
  itens: PedidoItem[];
  obs: string;
}

interface OrderFormProps {
  mLivre: boolean;
  resetKey: number;
  clientesDisponiveis: string[];
  editingPedido: Pedido | null;
  duplicatingPedido: Pedido | null;
  onCancelEdit: () => void;
  onCancelDuplicate: () => void;
  onRequestLaunch: (payload: DraftOrderPayload) => void;
}

export const OrderForm: React.FC<OrderFormProps> = ({
  mLivre,
  resetKey,
  clientesDisponiveis,
  editingPedido,
  duplicatingPedido,
  onCancelEdit,
  onCancelDuplicate,
  onRequestLaunch,
}) => {
  const [cliente, setCliente] = useState(mLivre ? 'M.LIVRE' : '');
  const [sugestoesVisiveis, setSugestoesVisiveis] = useState(false);
  const [sugestaoIdx, setSugestaoIdx] = useState(-1);

  const [dataEntrada, setDataEntrada] = useState(() => dataLocalISO());
  const [pretensaoEntrega, setPretensaoEntrega] = useState('');
  const [entregaMLivreHora, setEntregaMLivreHora] = useState('');
  const [urgente, setUrgente] = useState(false);

  const [tipoItem, setTipoItem] = useState<ItemTipo>('estribo');
  const [embalagem, setEmbalagem] = useState<EmbalagemTipo>('caixa');
  const [medida, setMedida] = useState('');
  const [bitola, setBitola] = useState('');
  const [outroNome, setOutroNome] = useState('');
  const [unidadeBobina, setUnidadeBobina] = useState<UnidadeOutro>('un');
  const [naoCaixaArame, setNaoCaixaArame] = useState(false);
  const [qtdTexto, setQtdTexto] = useState('');

  const [itens, setItens] = useState<PedidoItem[]>([]);
  const [itemEditIdx, setItemEditIdx] = useState<number | null>(null);
  const [obs, setObs] = useState('');
  const [formError, setFormError] = useState('');

  const autocompleteRef = useRef<HTMLDivElement>(null);
  const medidaInputRef = useRef<HTMLInputElement>(null);

  // Sync form state when editingPedido, duplicatingPedido, or mode changes
  useEffect(() => {
    setFormError('');
    setItemEditIdx(null);
    if (editingPedido) {
      setCliente(editingPedido.mLivre ? 'M.LIVRE' : editingPedido.cliente);
      setDataEntrada(editingPedido.dataEntrada || dataLocalISO());
      setPretensaoEntrega(editingPedido.mLivre ? '' : editingPedido.pretensaoEntrega || '');
      setEntregaMLivreHora(editingPedido.mLivre ? editingPedido.entregaMLivre || '' : '');
      setUrgente(editingPedido.mLivre ? false : editingPedido.urgente);
      setItens(editingPedido.itens.map((i) => ({ ...i })));
      setObs(editingPedido.obs || '');
      const firstType: ItemTipo = editingPedido.itens[0]?.tipo === 'outro' ? 'outro' : 'estribo';
      const firstItem = editingPedido.itens[0];
      setTipoItem(editingPedido.mLivre ? 'estribo' : firstType);
      setEmbalagem(
        editingPedido.mLivre
          ? firstItem && firstItem.tipo !== 'outro'
            ? embalagemDoItem(firstItem, true)
            : 'caixa'
          : 'pacote'
      );
      setMedida(editingPedido.mLivre ? editingPedido.itens[0]?.medida || '' : '');
      setBitola('');
      setOutroNome('');
      setUnidadeBobina('un');
      setQtdTexto('');
      setNaoCaixaArame(false);
    } else if (duplicatingPedido) {
      setCliente(duplicatingPedido.mLivre ? 'M.LIVRE' : duplicatingPedido.cliente);
      setDataEntrada(dataLocalISO());
      setPretensaoEntrega('');
      setEntregaMLivreHora('');
      setUrgente(false);
      setItens(duplicatingPedido.itens.map((i) => ({ ...i, pronto: false })));
      setObs(duplicatingPedido.obs || '');
      const firstType: ItemTipo = duplicatingPedido.itens[0]?.tipo === 'outro' ? 'outro' : 'estribo';
      const firstItem = duplicatingPedido.itens[0];
      setTipoItem(duplicatingPedido.mLivre ? 'estribo' : firstType);
      setEmbalagem(
        duplicatingPedido.mLivre
          ? firstItem && firstItem.tipo !== 'outro'
            ? embalagemDoItem(firstItem, true)
            : 'caixa'
          : 'pacote'
      );
      setMedida(duplicatingPedido.mLivre ? duplicatingPedido.itens[0]?.medida || '' : '');
      setBitola('');
      setOutroNome('');
      setUnidadeBobina('un');
      setQtdTexto('');
      setNaoCaixaArame(false);
    } else {
      setCliente(mLivre ? 'M.LIVRE' : '');
      setDataEntrada(dataLocalISO());
      setPretensaoEntrega('');
      setEntregaMLivreHora('');
      setUrgente(false);
      setItens([]);
      setObs('');
      setTipoItem('estribo');
      setEmbalagem(mLivre ? 'caixa' : 'pacote');
      setMedida('');
      setBitola('');
      setOutroNome('');
      setUnidadeBobina('un');
      setNaoCaixaArame(false);
      setQtdTexto('');
    }
    setSugestoesVisiveis(false);
  }, [editingPedido, duplicatingPedido, mLivre, resetKey]);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (autocompleteRef.current && !autocompleteRef.current.contains(e.target as Node)) {
        setSugestoesVisiveis(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const sugestoes = useMemo(() => {
    if (mLivre || !sugestoesVisiveis) return [];
    const termo = normalizarBusca(cliente);
    if (!termo) return [];
    return clientesDisponiveis
      .map((nome) => ({ nome, busca: normalizarBusca(nome) }))
      .filter((item) => item.busca.includes(termo))
      .sort((a, b) => {
        const aStarts = a.busca.startsWith(termo);
        const bStarts = b.busca.startsWith(termo);
        if (aStarts !== bStarts) return aStarts ? -1 : 1;
        return a.nome.localeCompare(b.nome, 'pt-BR');
      })
      .slice(0, 8)
      .map((item) => item.nome);
  }, [mLivre, sugestoesVisiveis, cliente, clientesDisponiveis]);

  const outroTipo = tipoMaterialOutro(outroNome);
  const telaDetectada = tipoItem === 'outro' ? telaPorCodigo(outroNome) : null;
  const mostraUnidade = tipoItem === 'outro' && (outroTipo === 'arame' || outroTipo === 'bobina');
  const pesoEmKg = mostraUnidade && unidadeBobina === 'kg';

  function handleAddOrUpdateItem() {
    setFormError('');

    if (!mLivre && tipoItem === 'outro') {
      const nome = outroNome.trim();
      const quantidade = lerQuantidade(qtdTexto);
      const unidade: UnidadeOutro =
        outroTipo === 'arame' || outroTipo === 'bobina' ? unidadeBobina : 'un';

      if (!nome) {
        setFormError('Informe o nome do material.');
        return;
      }
      if (!Number.isFinite(quantidade) || quantidade <= 0) {
        setFormError('Informe uma quantidade válida.');
        return;
      }
      if (unidade === 'un' && !Number.isInteger(quantidade)) {
        setFormError('A quantidade por unidade deve ser um número inteiro.');
        return;
      }

      const naoCaixa = outroTipo === 'arame' && unidade === 'kg' && naoCaixaArame;
      const caixas =
        outroTipo === 'arame' &&
        unidade === 'kg' &&
        !naoCaixa &&
        Math.abs(quantidade / 20 - Math.round(quantidade / 20)) < 1e-9
          ? Math.round(quantidade / 20)
          : 0;

      const tela = outroTipo === 'tela' ? telaPorCodigo(nome) : null;
      if (outroTipo === 'tela' && !tela) {
        setFormError('Código de tela inválido. Use Q138, Q61, Q92 ou Q45.');
        return;
      }

      const itemNovo: PedidoItem = {
        tipo: 'outro',
        medida: tela ? tela.medida : '—',
        material: tela ? 'Tela' : nome,
        codigo: tela?.codigo || '',
        bitola: tela?.bitola || '',
        qtd: quantidade,
        unidade,
        caixas,
        naoCaixa,
      };

      setItens((prev) =>
        itemEditIdx !== null
          ? prev.map((it, i) => (i === itemEditIdx ? itemNovo : it))
          : [...prev, itemNovo]
      );
      setItemEditIdx(null);
      setOutroNome('');
      setQtdTexto('');
      setUnidadeBobina('un');
      setNaoCaixaArame(false);
      return;
    }

    // Estribo (normal or M.Livre)
    const med = medida.trim();
    const rawBitola = mLivre ? '4.2' : bitola.trim().replace(',', '.');
    const normalizedBitola = rawBitola === '5' ? '5.0' : rawBitola === '6' ? '6.0' : rawBitola;
    const mat = (MATERIAIS as readonly string[]).includes(normalizedBitola) ? normalizedBitola : '';
    const qtd = lerQuantidade(qtdTexto);

    if (!med) {
      setFormError('Informe a medida.');
      return;
    }
    if (!mat) {
      setFormError('Bitola inválida. Use 3,8; 4,2; 5,0 ou 6,0 mm.');
      return;
    }
    if (!Number.isFinite(qtd) || qtd <= 0 || !Number.isInteger(qtd)) {
      setFormError('Informe um número inteiro positivo para a quantidade.');
      return;
    }

    if (mLivre) {
      const outras = itens.filter((_, i) => i !== itemEditIdx);
      if (outras.some((x) => x.medida !== med || x.material !== mat)) {
        setFormError('Todos os volumes de um pedido M.Livre devem ter a mesma medida e bitola.');
        return;
      }

      const nextList =
        itemEditIdx !== null
          ? itens.map((it, i) => {
              if (i !== itemEditIdx) return it;
              const { unidadeLancamento: _omit, ...rest } = it;
              return {
                ...rest,
                medida: med,
                material: mat,
                qtd,
                embalagem,
                ...(embalagem === 'caixa' ? { unidadeLancamento: 'caixa' as const } : {}),
              };
            })
          : [
              ...itens,
              {
                tipo: 'estribo' as const,
                medida: med,
                material: mat,
                qtd,
                embalagem,
                ...(embalagem === 'caixa' ? { unidadeLancamento: 'caixa' as const } : {}),
                caixaNumero: itens.length + 1,
                pronto: false,
              },
            ];

      setItens(nextList.map((x, idx) => ({ ...x, caixaNumero: idx + 1 })));
      setItemEditIdx(null);
      setQtdTexto('');
      medidaInputRef.current?.focus();
      return;
    }

    const itemNovo: PedidoItem = {
      tipo: 'estribo',
      medida: med,
      material: mat,
      qtd,
      embalagem: 'pacote',
      pronto: false,
    };

    setItens((prev) =>
      itemEditIdx !== null
        ? prev.map((it, i) => (i === itemEditIdx ? itemNovo : it))
        : [...prev, itemNovo]
    );
    setItemEditIdx(null);
    setMedida('');
    setBitola('');
    setEmbalagem('pacote');
    setQtdTexto('');
    medidaInputRef.current?.focus();
  }

  function handleEditDraftItem(idx: number) {
    const item = itens[idx];
    if (!item) return;
    setFormError('');
    setItemEditIdx(idx);

    if (item.tipo === 'outro') {
      setTipoItem('outro');
      setOutroNome(item.codigo || item.material);
      setUnidadeBobina(item.unidade || 'un');
      setQtdTexto(String(item.qtd).replace('.', ','));
      setNaoCaixaArame(Boolean(item.naoCaixa));
    } else {
      setTipoItem('estribo');
      setEmbalagem(mLivre ? embalagemDoItem(item, true) : 'pacote');
      setMedida(item.medida);
      if (!mLivre) setBitola(item.material.replace('.', ','));
      setQtdTexto(String(item.qtd));
    }
  }

  function handleCancelDraftItemEdit() {
    setFormError('');
    setItemEditIdx(null);
    setEmbalagem(mLivre ? 'caixa' : 'pacote');
    if (!mLivre) {
      setMedida('');
      setBitola('');
    }
    setOutroNome('');
    setUnidadeBobina('un');
    setNaoCaixaArame(false);
    setQtdTexto('');
  }

  function handleDeleteDraftItem(idx: number) {
    setFormError('');
    setItens((prev) => {
      const next = prev.filter((_, i) => i !== idx);
      return mLivre ? next.map((x, i) => ({ ...x, caixaNumero: i + 1 })) : next;
    });
    if (itemEditIdx === idx) {
      setItemEditIdx(null);
      setQtdTexto('');
    } else if (itemEditIdx !== null && itemEditIdx > idx) {
      setItemEditIdx(itemEditIdx - 1);
    }
  }

  function handleSubmitOrder() {
    setFormError('');
    const clienteFinal = mLivre ? 'M.LIVRE' : cliente.trim();
    if (!clienteFinal) {
      setFormError('Informe o nome do cliente.');
      return;
    }
    if (itemEditIdx !== null) {
      setFormError('Conclua ou remova o item em edição antes de lançar.');
      return;
    }
    if (!itens.length) {
      setFormError('Adicione pelo menos 1 item ao pedido.');
      return;
    }
    if (!dataEntrada) {
      setFormError('Informe a data de entrada.');
      return;
    }
    if (mLivre && !entregaMLivreHora) {
      setFormError('Informe a hora limite de entrega.');
      return;
    }
    if (!mLivre && pretensaoEntrega && pretensaoEntrega < dataEntrada) {
      setFormError('A entrega prevista não pode ser anterior à data de entrada.');
      return;
    }

    onRequestLaunch({
      editingId: editingPedido?.id || null,
      mLivre,
      cliente: clienteFinal,
      dataEntrada,
      pretensaoEntrega: mLivre ? '' : pretensaoEntrega,
      entregaMLivreHora: mLivre ? entregaMLivreHora : '',
      urgente: mLivre ? false : urgente,
      itens,
      obs: obs.trim(),
    });
  }

  return (
    <section
      className={`border rounded-xl p-4 sm:p-6 ${
        mLivre ? 'bg-yellow-50/70 border-yellow-300' : 'bg-white border-slate-200'
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
        <div className="flex flex-wrap items-baseline gap-2">
          <h2 className="text-lg font-extrabold text-slate-900">
            {editingPedido
              ? 'Editar pedido'
              : mLivre
              ? 'Novo lançamento M.Livre'
              : 'Novo lançamento'}
          </h2>
          {!editingPedido && duplicatingPedido && (
            <span className="text-xs font-semibold text-amber-800">
              Copiado de {duplicatingPedido.cliente}
            </span>
          )}
        </div>
        {editingPedido ? (
          <button
            type="button"
            onClick={onCancelEdit}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 underline cursor-pointer"
          >
            Cancelar edição
          </button>
        ) : duplicatingPedido ? (
          <button
            type="button"
            onClick={onCancelDuplicate}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 underline cursor-pointer"
          >
            Limpar cópia
          </button>
        ) : null}
      </div>

      {/* Header fields */}
      <div className="flex flex-wrap items-end gap-3">
        {!mLivre && (
          <div
            ref={autocompleteRef}
            className="relative w-full sm:flex-1 sm:min-w-[240px] sm:max-w-md flex flex-col gap-1"
          >
            <label htmlFor="clienteBusca" className="text-xs font-semibold text-slate-500">
              Cliente *
            </label>
            <input
              id="clienteBusca"
              type="text"
              autoComplete="off"
              placeholder="Nome do cliente"
              value={cliente}
              onChange={(e) => {
                setCliente(e.target.value);
                setSugestoesVisiveis(true);
                setSugestaoIdx(-1);
              }}
              onKeyDown={(e) => {
                if (!sugestoes.length) return;
                if (e.key === 'ArrowDown') {
                  e.preventDefault();
                  setSugestaoIdx((prev) => Math.min(prev + 1, sugestoes.length - 1));
                } else if (e.key === 'ArrowUp') {
                  e.preventDefault();
                  setSugestaoIdx((prev) => Math.max(prev - 1, 0));
                } else if (e.key === 'Enter' && sugestaoIdx >= 0) {
                  e.preventDefault();
                  setCliente(sugestoes[sugestaoIdx]);
                  setSugestoesVisiveis(false);
                } else if (e.key === 'Escape') {
                  setSugestoesVisiveis(false);
                }
              }}
              className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
            />
            {sugestoes.length > 0 && (
              <div
                role="listbox"
                className="absolute left-0 right-0 top-[calc(100%+4px)] z-30 max-h-52 overflow-auto bg-white border border-slate-200 rounded-lg shadow-lg p-1"
              >
                {sugestoes.map((nome, idx) => (
                  <button
                    key={nome}
                    type="button"
                    role="option"
                    aria-selected={idx === sugestaoIdx}
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => {
                      setCliente(nome);
                      setSugestoesVisiveis(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-sm rounded-md cursor-pointer ${
                      idx === sugestaoIdx
                        ? 'bg-red-50 text-red-700 font-semibold'
                        : 'text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    {nome}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex-1 min-w-[155px] sm:flex-none sm:w-44 flex flex-col gap-1">
          <label htmlFor="dataEntradaPedido" className="text-xs font-semibold text-slate-500">
            Data de entrada *
          </label>
          <input
            id="dataEntradaPedido"
            type="date"
            value={dataEntrada}
            onChange={(e) => setDataEntrada(e.target.value)}
            className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
          />
        </div>

        {mLivre ? (
          <div className="w-36 flex flex-col gap-1">
            <label htmlFor="entregaMLivreHora" className="text-xs font-semibold text-slate-500">
              Hora limite *
            </label>
            <input
              id="entregaMLivreHora"
              type="time"
              value={entregaMLivreHora}
              onChange={(e) => setEntregaMLivreHora(e.target.value)}
              className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
            />
          </div>
        ) : (
          <div className="flex-1 min-w-[155px] sm:flex-none sm:w-44 flex flex-col gap-1">
            <label htmlFor="pretensaoEntrega" className="text-xs font-semibold text-slate-500">
              Entrega prevista
            </label>
            <input
              id="pretensaoEntrega"
              type="date"
              value={pretensaoEntrega}
              onChange={(e) => setPretensaoEntrega(e.target.value)}
              className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
            />
          </div>
        )}
      </div>

      {!mLivre && (
        <div className="mt-3 flex items-center">
          <label className="inline-flex items-center gap-2.5 text-sm font-semibold text-slate-800 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={urgente}
              onChange={(e) => setUrgente(e.target.checked)}
              className="w-4 h-4 accent-red-600 rounded"
            />
            Pedido urgente
          </label>
        </div>
      )}

      {/* Items section */}
      <div className="mt-5 pt-4 border-t border-slate-100">
        <div className="flex flex-col items-start gap-2 mb-3">
          <h3 className="text-sm font-bold text-slate-800">Itens do pedido</h3>

          <div className="flex flex-wrap items-center gap-3">
            {!mLivre && (
              <div className="inline-flex p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => {
                    if (tipoItem !== 'estribo') {
                      setTipoItem('estribo');
                      setItemEditIdx(null);
                      setFormError('');
                    }
                  }}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    tipoItem === 'estribo'
                      ? 'bg-white text-red-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Estribo
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (tipoItem !== 'outro') {
                      setTipoItem('outro');
                      setItemEditIdx(null);
                      setFormError('');
                    }
                  }}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    tipoItem === 'outro'
                      ? 'bg-white text-red-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Outro material
                </button>
              </div>
            )}

            {mLivre && (
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-500">Embalagem:</span>
                <div
                  role="radiogroup"
                  aria-label="Tipo de embalagem"
                  className="inline-flex p-1 bg-slate-100 rounded-lg"
                >
                  <button
                    type="button"
                    role="radio"
                    aria-checked={embalagem === 'caixa'}
                    onClick={() => setEmbalagem('caixa')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      embalagem === 'caixa'
                        ? 'bg-white text-yellow-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Caixa
                  </button>
                  <button
                    type="button"
                    role="radio"
                    aria-checked={embalagem === 'pacote'}
                    onClick={() => setEmbalagem('pacote')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      embalagem === 'pacote'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Pacote
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-end gap-2.5">
          {!mLivre && tipoItem === 'outro' ? (
            <>
              <div className="w-full sm:w-64 flex flex-col gap-1">
                <label htmlFor="itemOutroNome" className="text-xs font-semibold text-slate-500">
                  Material
                </label>
                <input
                  id="itemOutroNome"
                  type="text"
                  placeholder="Ex.: Arame, Q138, Barra, Bobina"
                  value={outroNome}
                  onChange={(e) => {
                    setOutroNome(e.target.value);
                    if (tipoMaterialOutro(e.target.value) !== 'arame') setNaoCaixaArame(false);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddOrUpdateItem();
                    }
                  }}
                  className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                />
              </div>

              {mostraUnidade && (
                <div className="w-full sm:w-44 flex flex-col gap-1">
                  <label htmlFor="itemUnidadeBobina" className="text-xs font-semibold text-slate-500">
                    Unidade
                  </label>
                  <select
                    id="itemUnidadeBobina"
                    value={unidadeBobina}
                    onChange={(e) => setUnidadeBobina(e.target.value as UnidadeOutro)}
                    className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                  >
                    <option value="un">Unidade</option>
                    <option value="kg">Quilogramas (kg)</option>
                  </select>
                </div>
              )}

              <div className="w-full sm:w-36 flex flex-col gap-1">
                <label htmlFor="itemQtd" className="text-xs font-semibold text-slate-500">
                  {pesoEmKg ? 'Peso (kg)' : 'Quantidade'}
                </label>
                <input
                  id="itemQtd"
                  type="text"
                  inputMode="decimal"
                  placeholder={pesoEmKg ? 'Ex.: 20' : 'Quantidade'}
                  value={qtdTexto}
                  onChange={(e) => setQtdTexto(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddOrUpdateItem();
                    }
                  }}
                  className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                />
              </div>
            </>
          ) : (
            <>
              <div className="w-full sm:w-44 flex flex-col gap-1">
                <label htmlFor="itemMedida" className="text-xs font-semibold text-slate-500">
                  Medida
                </label>
                <input
                  ref={medidaInputRef}
                  id="itemMedida"
                  type="text"
                  placeholder="Ex.: 15x20"
                  value={medida}
                  onChange={(e) => setMedida(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddOrUpdateItem();
                    }
                  }}
                  className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                />
              </div>

              <div className="w-28 flex flex-col gap-1">
                {mLivre ? (
                  <>
                    <span className="text-xs font-semibold text-slate-500">Bitola (mm)</span>
                    <div className="w-full min-h-[44px] px-3 py-2 flex items-center text-sm font-bold font-mono-num text-yellow-900 bg-yellow-100/80 border border-yellow-300 rounded-lg">
                      4,2 mm
                    </div>
                  </>
                ) : (
                  <>
                    <label htmlFor="itemMaterial" className="text-xs font-semibold text-slate-500">
                      Bitola (mm)
                    </label>
                    <input
                      id="itemMaterial"
                      type="text"
                      inputMode="decimal"
                      maxLength={5}
                      placeholder="Ex.: 4,2"
                      title="Bitolas aceitas: 3,8; 4,2; 5,0 ou 6,0 mm"
                      value={bitola}
                      onChange={(e) => setBitola(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddOrUpdateItem();
                        }
                      }}
                      className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                    />
                  </>
                )}
              </div>

              <div className="flex-1 min-w-[130px] sm:flex-none sm:w-40 flex flex-col gap-1">
                <label htmlFor="itemQtd" className="text-xs font-semibold text-slate-500">
                  {mLivre
                    ? embalagem === 'caixa'
                      ? 'Estribos na caixa'
                      : 'Estribos no pacote'
                    : 'Qtd. de peças'}
                </label>
                <input
                  id="itemQtd"
                  type="text"
                  inputMode="numeric"
                  placeholder={mLivre ? 'Ex.: 100' : 'Ex.: 500'}
                  value={qtdTexto}
                  onChange={(e) => setQtdTexto(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddOrUpdateItem();
                    }
                  }}
                  className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                />
              </div>
            </>
          )}

          <div className="w-full sm:w-auto flex items-center gap-2">
            <button
              type="button"
              onClick={handleAddOrUpdateItem}
              className="flex-1 sm:flex-none min-h-[44px] px-4 py-2 inline-flex items-center justify-center gap-1.5 text-sm font-bold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              {itemEditIdx !== null
                ? 'Atualizar'
                : mLivre
                ? embalagem === 'caixa'
                  ? 'Adicionar caixa'
                  : 'Adicionar pacote'
                : 'Adicionar'}
            </button>
            {itemEditIdx !== null && (
              <button
                type="button"
                onClick={handleCancelDraftItemEdit}
                className="min-h-[44px] px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg whitespace-nowrap cursor-pointer"
              >
                Cancelar
              </button>
            )}
          </div>
        </div>

        {/* Contextual helper only when needed */}
        {!mLivre && tipoItem === 'outro' && (
          <div className="mt-2 flex flex-wrap items-center gap-3">
            {telaDetectada && (
              <span className="text-xs font-medium text-slate-600">
                {telaDetectada.codigo} · {telaDetectada.medida} · {telaDetectada.bitola}
              </span>
            )}
            {outroTipo === 'arame' && pesoEmKg && (
              <button
                type="button"
                aria-pressed={naoCaixaArame}
                onClick={() => setNaoCaixaArame((prev) => !prev)}
                className={`px-3 py-1.5 text-xs font-bold border rounded-lg transition-colors cursor-pointer ${
                  naoCaixaArame
                    ? 'bg-red-700 text-white border-red-700'
                    : 'bg-white text-red-700 border-red-300 hover:bg-red-50'
                }`}
              >
                {naoCaixaArame ? 'Não é caixa (ativo)' : 'Não é caixa'}
              </button>
            )}
          </div>
        )}

        {/* Draft items */}
        {itens.length > 0 && (
          <ul className="mt-3 space-y-2">
            {itens.map((it, idx) => (
              <li
                key={idx}
                className={`flex flex-wrap items-center justify-between gap-2 px-3 py-2.5 rounded-lg border text-sm ${
                  itemEditIdx === idx
                    ? 'border-red-400 bg-red-50/40'
                    : 'border-slate-200 bg-slate-50'
                }`}
              >
                <span className="text-slate-800">
                  {it.tipo === 'outro' ? (
                    <>
                      <strong className="font-bold">
                        {it.codigo ? `${it.codigo} · ${it.medida} · ${it.bitola}` : it.material}
                      </strong>{' '}
                      · <span className="font-mono-num font-semibold">{textoQtdOutro(it)}</span>
                    </>
                  ) : (
                    (() => {
                      const emb = embalagemDoItem(it, mLivre);
                      return (
                        <>
                          <strong className="font-bold">
                            {mLivre ? `${emb === 'caixa' ? 'Caixa' : 'Pacote'} ${it.caixaNumero || idx + 1} · ` : ''}
                            {it.medida}
                          </strong>{' '}
                          ·{' '}
                          <span className={`font-bold font-mono-num ${bitolaClass(it.material)}`}>
                            {it.material} mm
                          </span>{' '}
                          ·{' '}
                          <span className="font-mono-num font-semibold">
                            {fmtQtd(it.qtd)} {mLivre ? 'estribos' : 'peças'}
                          </span>
                          {!mLivre && (
                            <span className="text-xs text-slate-500 ml-1.5 font-mono-num">
                              ({emb === 'caixa' ? 'Caixa' : `${pacotesDe(it.qtd)}`})
                            </span>
                          )}
                        </>
                      );
                    })()
                  )}
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleEditDraftItem(idx)}
                    className="min-h-[34px] px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-md cursor-pointer"
                  >
                    Editar
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteDraftItem(idx)}
                    aria-label={`Remover item ${idx + 1}`}
                    className="min-h-[34px] w-[34px] inline-flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Notes & submit */}
      <div className="mt-4">
        <label htmlFor="anotacoesCliente" className="sr-only">
          Anotações
        </label>
        <textarea
          id="anotacoesCliente"
          rows={2}
          placeholder="Observações (opcional)"
          value={obs}
          onChange={(e) => setObs(e.target.value)}
          className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
        />
      </div>

      {formError && (
        <p
          role="alert"
          className="mt-3 text-xs font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2"
        >
          {formError}
        </p>
      )}

      <div className="mt-4 flex flex-wrap justify-end gap-2.5">
        {editingPedido && (
          <button
            type="button"
            onClick={onCancelEdit}
            className="min-h-[44px] px-5 py-2.5 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
          >
            Cancelar
          </button>
        )}
        <button
          type="button"
          onClick={handleSubmitOrder}
          className="w-full sm:w-auto min-w-[180px] min-h-[44px] px-6 py-2.5 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors cursor-pointer"
        >
          {editingPedido ? 'Salvar alterações' : 'Lançar pedido'}
        </button>
      </div>
    </section>
  );
};
