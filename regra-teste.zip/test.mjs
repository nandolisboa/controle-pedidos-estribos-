import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { readFileSync } from 'node:fs';
const uidF='j4lP0mUvsXdwRGgpKuAejzzYqzz1';
const uidL='K9kHfZDrN3hRnWaDss49efL4g0N2';
const uidC='5ptZQgM8lXSbIy9TeqJ2eKpqSOE2';
const env=await initializeTestEnvironment({projectId:'demo-peso-mlivre',firestore:{rules:readFileSync('firestore.rules','utf8')}});
try {
 await env.withSecurityRulesDisabled(async ctx => {
  for(const collection of ['pedidos','fabricaPedidos']) {
   await setDoc(doc(ctx.firestore(),collection,'mercado'), {mLivre:true,temEstribo:true,pronto:false,entregue:false,estribosProntos:[false,false]});
   await setDoc(doc(ctx.firestore(),collection,'normal'), {temEstribo:true,pronto:false,entregue:false,estribosProntos:[false,false]});
  }
 });
 const f=env.authenticatedContext(uidF).firestore(); const c=env.authenticatedContext(uidC).firestore(); const l=env.authenticatedContext(uidL).firestore();
 for(const col of ['pedidos','fabricaPedidos']) {
  const mercado=doc(f,col,'mercado'); const normal=doc(f,col,'normal');
  await assertSucceeds(updateDoc(mercado,{estribosProntos:[true,false],pesoKgPorItem:{'0':12.5}}));
  await assertFails(updateDoc(normal,{estribosProntos:[true,false],pesoKgPorItem:{'0':12.5}}));
  await assertFails(updateDoc(mercado,{estribosProntos:[false,false],pesoKgPorItem:{'0':12.5},cliente:'alterado'}));
  await assertSucceeds(updateDoc(mercado,{estribosProntos:[false,false]}));
 }
 await assertSucceeds(getDoc(doc(c,'pedidos','mercado')));
 await assertFails(getDoc(doc(c,'pedidos','normal')));
 await assertFails(updateDoc(doc(c,'pedidos','mercado'),{pesoKgPorItem:{'0':9}}));
 await assertSucceeds(updateDoc(doc(l,'pedidos','mercado'),{cliente:'Lançamento'}));
 console.log('PASS: weights permitted only in M.Livre factory progress, normal updates preserved, read-only conference verified');
} finally {await env.cleanup();}
