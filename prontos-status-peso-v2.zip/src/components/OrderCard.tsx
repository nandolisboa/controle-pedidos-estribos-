import React, { useState } from 'react';
import { Copy, FileText, Pencil, Trash2 } from 'lucide-react';
import type { Pedido } from '../types';
import {
  bitolaClass,
  compararItensMLivre,
  dataEntradaDoPedido,
  embalagemDoItem,
  estadoProducaoPedido,
  fmtDataHora,
  fmtQtd,
  formatarDataISO,
  infoTelaDoItem,
  pacotesDe,
  textoQtdOutro,
} from '../utils';

interface OrderCardProps {
  pedido: Pedido;
  canEdit: boolean;
  onEdit: (id: string) => void;
  onDuplicate?: (id: string) => void;
  onPdf: (id: string) => void;
  onDelete: (id: string) => void;
  showWeightInputs?: boolean;
  onSaveItemWeight?: (id: string, itemIndex: number, weightKg: number | null) => Promise<void>;
}

export const OrderCard = React.memo<OrderCardProps>(
  ({
    pedido: p,
    canEdit,
    onEdit,
    onDuplicate,
    onPdf,
    onDelete,
    showWeightInputs = false,
    onSaveItemWeight,
  }) => {
    const [weightDraft, setWeightDraft] = useState<Record<number, string>>({});
    const [savingWeightIndex, setSavingWeightIndex] = useState<number | null>(null);
    const hasEstribo = p.itens.some((i) => i.tipo !== 'outro');
    const hasOutro = p.itens.some((i) => i.tipo === 'outro');
    const itensExibidos = p.itens.map((item, idx) => ({ item, idx }));
    if (p.mLivre) itensExibidos.sort((a, b) => compararItensMLivre(a.item, b.item) || a.idx - b.idx);

    const estadoProducao = estadoProducaoPedido(p);
    const statusLabel = p.entregue
      ? 'Entregue'
      : hasEstribo
      ? estadoProducao === 'pronto'
        ? 'Pronto'
        : estadoProducao === 'produzindo'
        ? 'Produzindo'
        : 'Esperado'
      : null;

    const cardTone = p.mLivre
      ? 'border-yellow-300 bg-yellow-100/45'
      : p.entregue || p.pronto
      ? 'border-emerald-300 bg-emerald-50/25'
      : p.urgente
      ? 'border-red-400 bg-red-50/35'
      : 'border-amber-300 bg-amber-50/20';

    const statusTone =
      p.entregue || estadoProducao === 'pronto'
        ? 'text-emerald-700 font-bold'
        : p.urgente
        ? 'text-red-700 font-bold'
        : estadoProducao === 'produzindo'
        ? 'text-blue-700 font-semibold'
        : 'text-amber-700 font-semibold';

    return (
      <article className={`rounded-xl border p-4 sm:p-5 transition-colors ${cardTone}`}>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 pb-3 border-b border-slate-200/70">
          <div className="min-w-0">
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight break-words">
              {p.cliente}
            </h3>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs mt-1 text-slate-600">
              {p.mLivre && <span className="font-bold text-yellow-800">M.Livre · Prioridade</span>}
              {p.mLivre && (p.urgente || statusLabel) && <span aria-hidden="true">·</span>}
              {p.urgente && !p.pronto && !p.entregue && (
                <>
                  <span className="font-bold text-red-700">Urgente</span>
                  {statusLabel && <span aria-hidden="true">·</span>}
                </>
              )}
              {statusLabel && <span className={statusTone}>{statusLabel}</span>}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-xs text-slate-600 font-mono-num shrink-0">
            <span>Entrada: {formatarDataISO(dataEntradaDoPedido(p))}</span>
            {p.mLivre && p.entregaMLivre ? (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-slate-800">Limite: {p.entregaMLivre}</span>
              </>
            ) : p.pretensaoEntrega ? (
              <>
                <span aria-hidden="true">·</span>
                <span>Entrega: {formatarDataISO(p.pretensaoEntrega)}</span>
              </>
            ) : null}
            {p.entregue && p.entregueEm ? (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-700 font-semibold">
                  Entregue: {fmtDataHora(p.entregueEm)}
                </span>
              </>
            ) : null}
          </div>
        </div>

        <div className="overflow-x-auto mt-2">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="text-[11px] font-semibold text-slate-500 border-b border-slate-200">
                <th className="py-2 pr-2 text-left">
                  {hasOutro ? 'Medida / material' : 'Medida'}
                </th>
                <th className="py-2 px-2 text-left">Material</th>
                <th className="py-2 px-2 text-right">
                  {p.mLivre ? 'Estribos' : hasOutro ? 'Quantidade' : 'Peças'}
                </th>
                {showWeightInputs && <th className="py-2 pl-2 text-left">Kg (opcional)</th>}
                {!p.mLivre && <th className="py-2 pl-2 text-right">Pacotes</th>}
                {p.mLivre && <th className="py-2 pl-2 text-right">Peso (kg)</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {itensExibidos.map(({ item, idx }) => {
                const tela = infoTelaDoItem(item);
                const emb = item.tipo !== 'outro' ? embalagemDoItem(item, p.mLivre) : null;
                return (
                  <tr key={idx} className="text-slate-800">
                    <td className="py-2 pr-2 font-semibold">
                      {item.tipo === 'outro'
                        ? tela?.medida || item.medida || '—'
                        : p.mLivre
                        ? `${emb === 'caixa' ? 'Cx ' : ''}${item.caixaNumero || idx + 1} · ${item.medida}`
                        : item.medida}
                    </td>
                    <td className="py-2 px-2">
                      {item.tipo === 'outro' ? (
                        tela ? (
                          <span>
                            {tela.codigo} · {tela.bitola}
                          </span>
                        ) : item.codigo ? (
                          <span>
                            {item.codigo} · {item.bitola}
                          </span>
                        ) : (
                          item.material
                        )
                      ) : (
                        <span className={`font-bold font-mono-num whitespace-nowrap ${bitolaClass(item.material)}`}>
                          {item.material} mm
                        </span>
                      )}
                    </td>
                    <td className="py-2 px-2 text-right font-mono-num whitespace-nowrap">
                      {item.tipo === 'outro'
                        ? textoQtdOutro(item)
                        : `${fmtQtd(item.qtd)}${p.mLivre ? ' est.' : ''}`}
                    </td>
                    {p.mLivre && <td className="py-2 pl-2 text-right font-mono-num">{p.pesoKgPorItem?.[String(idx)] ? `${Number(p.pesoKgPorItem[String(idx)]).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} kg` : '—'}</td>}
                    {showWeightInputs && (
                      <td className="py-2 pl-2">
                        {item.tipo !== 'outro' ? (() => {
                          const saved = p.pesoKgPorItem?.[String(idx)];
                          const value = weightDraft[idx] ?? (Number(saved) > 0 ? String(saved).replace('.', ',') : '');
                          const parsed = Number(value.replace(',', '.'));
                          const unchanged = value === (Number(saved) > 0 ? String(saved).replace('.', ',') : '');
                          const valid = value.trim() === '' || (Number.isFinite(parsed) && parsed > 0);
                          return <div className="flex items-center gap-1.5">
                            <input type="text" inputMode="decimal" aria-label={`Peso opcional em kg do estribo ${item.medida}`}
                              placeholder="kg opcional" value={value}
                              onChange={(event) => setWeightDraft((prev) => ({ ...prev, [idx]: event.target.value.replace(/[^0-9,.]/g, '') }))}
                              className="w-28 min-h-[38px] px-2 py-1 text-right text-sm font-mono-num bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-200 focus:border-emerald-500" />
                            <button type="button" disabled={!valid || unchanged || savingWeightIndex !== null || !onSaveItemWeight}
                              onClick={async () => {
                                if (!onSaveItemWeight || !valid) return;
                                setSavingWeightIndex(idx);
                                try {
                                  await onSaveItemWeight(p.id, idx, value.trim() ? parsed : null);
                                  setWeightDraft((prev) => { const next = { ...prev }; delete next[idx]; return next; });
                                } catch {
                                  // Keep the entered value so it can be retried; the parent displays the save error.
                                } finally { setSavingWeightIndex(null); }
                              }}
                              className="min-h-[38px] px-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed">
                              {savingWeightIndex === idx ? 'Salvando…' : 'Salvar'}
                            </button>
                          </div>;
                        })() : <span className="text-xs text-slate-400">—</span>}
                      </td>
                    )}
                    {!p.mLivre && (
                      <td className="py-2 pl-2 text-right font-mono-num font-semibold">
                        {item.tipo === 'outro'
                          ? ''
                          : emb === 'caixa'
                          ? 'Caixa'
                          : `${pacotesDe(item.qtd)}`}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {p.obs && (
          <p className="mt-3 px-3 py-2 rounded-lg bg-slate-100/80 text-xs text-slate-700">
            <span className="font-semibold text-slate-900">Obs.:</span> {p.obs}
          </p>
        )}

        <div className="mt-3 pt-3 border-t border-slate-200/60 flex flex-wrap items-center justify-end gap-2">
          {canEdit && (
            <button
              type="button"
              onClick={() => onEdit(p.id)}
              className="min-h-[40px] px-3.5 py-2 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors cursor-pointer"
            >
              <Pencil className="w-3.5 h-3.5" />
              Editar
            </button>
          )}
          {canEdit && onDuplicate && (
            <button
              type="button"
              onClick={() => onDuplicate(p.id)}
              className="min-h-[40px] px-3.5 py-2 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              Duplicar
            </button>
          )}
          <button
            type="button"
            onClick={() => onPdf(p.id)}
            className="min-h-[40px] px-3.5 py-2 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            PDF
          </button>
          {canEdit && (
            <button
              type="button"
              onClick={() => onDelete(p.id)}
              aria-label={`Excluir pedido de ${p.cliente}`}
              title="Excluir pedido"
              className="min-h-[40px] w-[40px] inline-flex items-center justify-center text-red-600 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </article>
    );
  }
);
