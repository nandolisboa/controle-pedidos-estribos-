import React, { useMemo, useState } from 'react';
import { Check, ChevronDown, ChevronRight, RefreshCw } from 'lucide-react';
import type { Pedido } from '../types';
import {
  bitolaClass,
  dataEntradaDoPedido,
  embalagemDoItem,
  fmtQtd,
  formatarDataISO,
  ordenarPedidos,
  ordenarPedidosMLivre,
  pacotesDe,
} from '../utils';

interface FactoryCardProps {
  pedido: Pedido;
  mLivreMode: boolean;
  highlightBitola?: string | null;
  onToggleItem: (pedidoId: string, itemIdx: number, pesoKg?: number) => void;
  onConfirmOrderReady: (pedidoId: string) => void;
}

const FactoryCard = React.memo<FactoryCardProps>(
  ({ pedido: p, mLivreMode, highlightBitola = null, onToggleItem, onConfirmOrderReady }) => {
    const [pesoDraft, setPesoDraft] = useState<Record<number, string>>({});
    const estribos = p.itens.filter((i) => i.tipo !== 'outro');
    const checks = estribos.map((item, idx) => Boolean(p.estribosProntos?.[idx] ?? item.pronto));
    const checkedCount = checks.filter(Boolean).length;
    const allChecked = estribos.length > 0 && checkedCount === estribos.length;
    const allWeightsEntered = estribos.every((_, idx) => Number(p.pesoKgPorItem?.[String(idx)]) > 0);

    const cardTone = mLivreMode
      ? 'border-yellow-300 bg-yellow-100/45'
      : p.pronto
      ? 'border-emerald-300 bg-emerald-50/25'
      : p.urgente
      ? 'border-red-400 bg-red-50/35'
      : 'border-amber-300 bg-amber-50/15';

    return (
      <article className={`rounded-xl border p-4 ${cardTone}`}>
        <div className="flex flex-wrap items-start justify-between gap-2 pb-2.5 border-b border-slate-200/70">
          <div className="min-w-0">
            <h3 className="text-base font-extrabold text-slate-900 break-words">{p.cliente}</h3>
            <div className="flex flex-wrap items-center gap-x-2 text-xs mt-0.5 text-slate-600 font-mono-num">
              <span>Entrada: {formatarDataISO(dataEntradaDoPedido(p))}</span>
              {mLivreMode && p.entregaMLivre ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold text-slate-800">Limite: {p.entregaMLivre}</span>
                </>
              ) : p.pretensaoEntrega ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Entrega: {formatarDataISO(p.pretensaoEntrega)}</span>
                </>
              ) : null}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs shrink-0">
            {p.urgente && !p.pronto && <span className="font-bold text-red-700">Urgente</span>}
            {p.urgente && !p.pronto && <span aria-hidden="true" className="text-slate-400">·</span>}
            <span className={p.pronto ? 'font-bold text-emerald-700' : 'font-semibold text-amber-700'}>
              {p.pronto ? 'Pronto' : 'Produzindo'}
            </span>
          </div>
        </div>

        {p.obs && (
          <p className="mt-2.5 px-3 py-2 rounded-lg bg-slate-100/80 text-xs text-slate-700">
            <span className="font-semibold text-slate-900">Obs.:</span> {p.obs}
          </p>
        )}

        <div className="overflow-x-auto mt-2">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="text-[11px] font-semibold text-slate-500 border-b border-slate-200">
                <th className="py-2 pr-2 text-left">Medida</th>
                <th className="py-2 px-2 text-left">Bitola</th>
                <th className="py-2 px-2 text-right">
                  {mLivreMode ? 'Emb. · Estribos' : 'Peças · Pacotes'}
                </th>
                {mLivreMode && <th className="py-2 px-2 text-right">Peso (kg)</th>}
                <th className="py-2 pl-2 text-center w-14">Pronto</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {estribos.map((item, idx) => {
                const checked = checks[idx];
                const dimmed = Boolean(highlightBitola && item.material !== highlightBitola);
                const emb = embalagemDoItem(item, mLivreMode);
                return (
                  <tr
                    key={idx}
                    className={`${checked ? 'bg-emerald-50/50' : ''} ${dimmed ? 'opacity-40' : ''}`}
                  >
                    <td className="py-2 pr-2 font-semibold text-slate-900">{item.medida}</td>
                    <td className={`py-2 px-2 font-bold font-mono-num whitespace-nowrap ${bitolaClass(item.material)}`}>
                      {item.material} mm
                    </td>
                    <td className="py-2 px-2 text-right font-mono-num whitespace-nowrap text-slate-800">
                      {mLivreMode
                        ? `${emb === 'caixa' ? 'Cx ' : ''}${item.caixaNumero || idx + 1} · ${fmtQtd(item.qtd)}`
                        : `${fmtQtd(item.qtd)} · ${emb === 'caixa' ? 'Caixa' : `${pacotesDe(item.qtd)}`}`}
                    </td>
                    {mLivreMode && (
                      <td className="py-1.5 px-2 text-right">
                        {mLivreMode && !checked ? (
                          <input
                            type="text"
                            inputMode="decimal"
                            aria-label={`Peso em kg da medida ${item.medida}`}
                            
                            value={pesoDraft[idx] ?? (p.pesoKgPorItem?.[String(idx)] ? String(p.pesoKgPorItem[String(idx)]).replace('.', ',') : '')}
                            onChange={(e) => setPesoDraft((prev) => ({ ...prev, [idx]: e.target.value.replace(/[^0-9,.]/g, '') }))}
                            className="w-24 min-h-[38px] px-2 py-1 text-right text-sm font-mono-num bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-200 focus:border-yellow-500"
                          />
                        ) : p.pesoKgPorItem?.[String(idx)] ? (
                          <span className="font-mono-num text-xs font-semibold text-slate-700">
                            {Number(p.pesoKgPorItem[String(idx)]).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 3 })} kg
                          </span>
                        ) : '—'}
                      </td>
                    )}
                    <td className="py-1.5 pl-2 text-center">
                      <button
                        type="button"
                        disabled={mLivreMode && !checked && !(Number(String(pesoDraft[idx] ?? p.pesoKgPorItem?.[String(idx)] ?? '').replace(',', '.')) > 0)}
                        onClick={() => {
                          const kg = Number(String(pesoDraft[idx] ?? p.pesoKgPorItem?.[String(idx)] ?? '').replace(',', '.'));
                          const raw = String(pesoDraft[idx] ?? p.pesoKgPorItem?.[String(idx)] ?? '').trim();
                          if (mLivreMode && !checked && (!raw || !Number.isFinite(kg) || kg <= 0)) return;
                          onToggleItem(p.id, idx, mLivreMode && !checked ? kg : undefined);
                        }}
                        aria-pressed={checked}
                        aria-label={checked ? 'Desmarcar item pronto' : 'Marcar item pronto'}
                        className="w-10 h-10 inline-flex items-center justify-center rounded-lg hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                      >
                        <span
                          className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                            checked
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'bg-white border-slate-400 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center justify-between gap-3">
          <span className="text-xs font-medium text-slate-500 font-mono-num">
            {checkedCount}/{estribos.length} itens
          </span>

          {!p.pronto && allChecked && (!mLivreMode || allWeightsEntered) && (
            <button
              type="button"
              onClick={() => onConfirmOrderReady(p.id)}
              className="min-h-[40px] px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors cursor-pointer"
            >
              Confirmar pedido pronto
            </button>
          )}
        </div>
      </article>
    );
  }
);

interface FactoryViewProps {
  pedidos: Pedido[];
  mLivreMode: boolean;
  onAtualizar: () => void;
  atualizando: boolean;
  onToggleItem: (pedidoId: string, itemIdx: number, pesoKg?: number) => void;
  onConfirmOrderReady: (pedidoId: string) => void;
}

export const FactoryView: React.FC<FactoryViewProps> = ({
  pedidos,
  mLivreMode,
  onAtualizar,
  atualizando,
  onToggleItem,
  onConfirmOrderReady,
}) => {
  const [prontosOpen, setProntosOpen] = useState(false);
  const [bitolaFiltro, setBitolaFiltro] = useState<string>('todas');

  const activeBitolaFiltro = mLivreMode ? 'todas' : bitolaFiltro;

  const { regulares, urgentes, prontos } = useMemo(() => {
    const filtered = pedidos.filter((p) => {
      if (Boolean(p.mLivre) !== mLivreMode || p.entregue) return false;
      const estribos = p.itens.filter((i) => i.tipo !== 'outro');
      if (!estribos.length) return false;
      if (activeBitolaFiltro !== 'todas' && !estribos.some((i) => i.material === activeBitolaFiltro)) {
        return false;
      }
      return true;
    });
    const ordenarFila = mLivreMode ? ordenarPedidosMLivre : ordenarPedidos;
    const emProd = ordenarFila(filtered.filter((p) => !p.pronto));
    return {
      regulares: emProd.filter((p) => !p.urgente),
      urgentes: emProd.filter((p) => p.urgente),
      prontos: ordenarFila(filtered.filter((p) => p.pronto)),
    };
  }, [pedidos, mLivreMode, activeBitolaFiltro]);

  const temFiltroAtivo = activeBitolaFiltro !== 'todas';
  const showProntosOpen =
    prontosOpen || (temFiltroAtivo && regulares.length === 0 && urgentes.length === 0 && prontos.length > 0);

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <button
          type="button"
          onClick={onAtualizar}
          disabled={atualizando}
          className="min-h-[42px] px-4 py-2 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer disabled:opacity-60 disabled:cursor-wait"
          title="Buscar pedidos novamente"
        >
          <RefreshCw className={`w-4 h-4 text-slate-600 ${atualizando ? 'animate-spin' : ''}`} />
          {atualizando ? 'Atualizando...' : 'Atualizar'}
        </button>
      </div>
      {!mLivreMode && (
        <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
          <div
            role="group"
            aria-label="Filtrar por bitola"
            className="flex flex-wrap items-center gap-1.5"
          >
            <button
              type="button"
              onClick={() => setBitolaFiltro('todas')}
              className={`min-h-[42px] px-3 text-xs font-bold rounded-lg border transition-colors cursor-pointer ${
                bitolaFiltro === 'todas'
                  ? 'border-slate-900 bg-slate-900 text-white'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              Todas
            </button>
            {temFiltroAtivo && (
              <button
                type="button"
                onClick={() => setBitolaFiltro('todas')}
                className="min-h-[42px] px-3 text-xs font-semibold text-slate-600 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
              >
                Limpar
              </button>
            )}
          </div>
        </div>
      )}

      {!mLivreMode && urgentes.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <h2 className="text-sm font-bold text-red-700">Urgentes</h2>
            <span className="text-xs font-mono-num font-bold text-red-700">{urgentes.length}</span>
          </div>
          <div className="space-y-3">
            {urgentes.map((p) => (
              <FactoryCard
                key={p.id}
                pedido={p}
                mLivreMode={false}
                highlightBitola={activeBitolaFiltro === 'todas' ? null : activeBitolaFiltro}
                onToggleItem={onToggleItem}
                onConfirmOrderReady={onConfirmOrderReady}
              />
            ))}
          </div>
        </section>
      )}

      <section className="space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <h2
            className={`text-sm font-bold ${
              mLivreMode ? 'text-yellow-950 border-l-4 border-yellow-400 pl-2' : 'text-slate-800'
            }`}
          >
            {mLivreMode ? 'M.Livre · Fila de produção' : 'Em produção'}
          </h2>
          <span className="text-xs font-mono-num font-bold text-slate-600">
            {regulares.length}
          </span>
        </div>
        {regulares.length ? (
          <div className="space-y-3">
            {regulares.map((p) => (
              <FactoryCard
                key={p.id}
                pedido={p}
                mLivreMode={mLivreMode}
                highlightBitola={activeBitolaFiltro === 'todas' ? null : activeBitolaFiltro}
                onToggleItem={onToggleItem}
                onConfirmOrderReady={onConfirmOrderReady}
              />
            ))}
          </div>
        ) : (
          <p className="text-center text-sm text-slate-500 py-8 bg-white border border-slate-200 rounded-xl">
            Nenhum pedido em produção.
          </p>
        )}
      </section>

      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <button
          type="button"
          onClick={() => setProntosOpen((prev) => !prev)}
          aria-expanded={showProntosOpen}
          className="w-full min-h-[48px] px-4 py-3 flex items-center justify-between text-sm font-bold text-emerald-800 hover:bg-slate-50 cursor-pointer"
        >
          <span className="flex items-center gap-2">
            {showProntosOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            Prontos
          </span>
          <span className="font-mono-num text-xs font-bold">{prontos.length}</span>
        </button>

        {showProntosOpen && (
          <div className="p-3 pt-1 border-t border-slate-100 space-y-3">
            {prontos.length ? (
              prontos.map((p) => (
                <FactoryCard
                  key={p.id}
                  pedido={p}
                  mLivreMode={mLivreMode}
                  highlightBitola={activeBitolaFiltro === 'todas' ? null : activeBitolaFiltro}
                  onToggleItem={onToggleItem}
                  onConfirmOrderReady={onConfirmOrderReady}
                />
              ))
            ) : (
              <p className="text-center text-sm text-slate-500 py-4">Nenhum pedido pronto.</p>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
