self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil((async () => {
    const clientsList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clientsList) {
      if ('focus' in client) return client.focus();
    }
    return self.clients.openWindow(new URL('./', self.registration.scope).toString());
  })());
});
