import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut, type User } from 'firebase/auth';
import {
  collection,
  doc,
  getDocs,
  getFirestore,
  initializeFirestore,
  onSnapshot,
  persistentLocalCache,
  persistentMultipleTabManager,
  query,
  where,
  writeBatch,
  type Firestore,
  type Unsubscribe,
} from 'firebase/firestore';
import type { Pedido, PedidoItem, PedidoWritePayload, UserRole } from './types';

const firebaseConfig = {
  apiKey: 'AIzaSyA4mosOkYxtWopiqADZbSisL-c0n7DzeVU',
  authDomain: 'lancamento-952ad.firebaseapp.com',
  projectId: 'lancamento-952ad',
  storageBucket: 'lancamento-952ad.firebasestorage.app',
  messagingSenderId: '73058817158',
  appId: '1:73058817158:web:be7281a7093dd1dc17ed07',
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

let db: Firestore;
try {
  db = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
  });
} catch {
  db = getFirestore(app);
}

export const ROLE_UIDS: Record<string, UserRole> = {
  K9kHfZDrN3hRnWaDss49efL4g0N2: 'lancamento',
  j4lP0mUvsXdwRGgpKuAejzzYqzz1: 'fabrica',
  '5ptZQgM8lXSbIy9TeqJ2eKpqSOE2': 'conferencia',
};

export function resolveUserRole(user: User | null): UserRole | null {
  if (!user) return null;
  return ROLE_UIDS[user.uid] ?? null;
}

export function signInUser(email: string, password: string) {
  return signInWithEmailAndPassword(auth, email, password);
}

export function signOutUser() {
  return signOut(auth);
}

export function subscribeAuth(cb: (user: User | null) => void) {
  return onAuthStateChanged(auth, cb);
}

function normalizePedidoDoc(id: string, raw: Record<string, unknown>): Pedido {
  const rawItens = Array.isArray(raw.itens) ? (raw.itens as PedidoItem[]) : [];
  const rawProntos = Array.isArray(raw.estribosProntos) ? (raw.estribosProntos as boolean[]) : null;
  const pronto = raw.pronto === true;

  let estriboIdx = 0;
  const itens: PedidoItem[] = rawItens.map((item) => {
    if (item?.tipo === 'outro') return item;
    const itemPronto = rawProntos ? rawProntos[estriboIdx] === true : item?.pronto === true;
    estriboIdx++;
    return { ...item, pronto: itemPronto || pronto };
  });

  const estribosProntos: boolean[] = rawProntos
    ? rawProntos
    : itens.filter((i) => i.tipo !== 'outro').map((i) => i.pronto === true || pronto);

  return {
    id,
    cliente: String(raw.cliente || ''),
    itens,
    estribosProntos,
    criadoEm: Number(raw.criadoEm) || 0,
    dataEntrada: String(raw.dataEntrada || ''),
    pretensaoEntrega: String(raw.pretensaoEntrega || ''),
    urgente: raw.urgente === true,
    mLivre: raw.mLivre === true,
    entregaMLivre: String(raw.entregaMLivre || ''),
    mLivreVisto: raw.mLivreVisto === true,
    mLivreVistoEm: raw.mLivreVistoEm ? Number(raw.mLivreVistoEm) : undefined,
    pronto,
    prontoEm: (raw.prontoEm as number | null) ?? null,
    entregue: raw.entregue === true,
    entregueEm: (raw.entregueEm as number | null) ?? null,
    temEstribo: raw.temEstribo !== false,
    obs: String(raw.obs || ''),
    pesoKgPorItem: raw.pesoKgPorItem && typeof raw.pesoKgPorItem === 'object'
      ? raw.pesoKgPorItem as Record<string, number>
      : {},
  };
}

function buildFabricaMirror(data: PedidoWritePayload) {
  const estriboItems = data.itens.filter((i) => i.tipo !== 'outro');
  return {
    cliente: data.cliente,
    kg: 0,
    urgente: !!data.urgente,
    criadoEm: data.criadoEm,
    dataEntrada: data.dataEntrada || '',
    pretensaoEntrega: data.pretensaoEntrega || '',
    obs: data.obs || '',
    pronto: !!data.pronto,
    prontoEm: data.prontoEm ?? null,
    estribosProntos: Array.isArray(data.estribosProntos)
      ? data.estribosProntos
      : estriboItems.map((i) => i.pronto === true || data.pronto === true),
    entregue: !!data.entregue,
    entregueEm: data.entregueEm ?? null,
    temEstribo: true,
    ...(data.mLivre ? { mLivre: true, entregaMLivre: data.entregaMLivre || '', pesoKgPorItem: data.pesoKgPorItem || {} } : {}),
    itens: estriboItems.map((i) => ({
      tipo: 'estribo' as const,
      medida: i.medida,
      material: i.material,
      qtd: i.qtd,
      pronto: i.pronto === true,
      ...(i.embalagem ? { embalagem: i.embalagem } : {}),
      ...(data.mLivre ? { caixaNumero: i.caixaNumero || 0 } : {}),
    })),
  };
}

export interface SnapshotEvents {
  novos: Pedido[];
  prontosAgora: Pedido[];
}

export function listenPedidos(
  role: UserRole,
  onData: (pedidos: Pedido[], events: SnapshotEvents, isFirstLoad: boolean) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const colecao = role === 'fabrica' ? 'fabricaPedidos' : 'pedidos';
  const q = role === 'conferencia'
    ? query(collection(db, colecao), where('mLivre', '==', true))
    : query(collection(db, colecao), where('entregue', '==', false));
  let firstLoad = true;
  const previousReadyMap = new Map<string, boolean>();

  return onSnapshot(
    q,
    (snapshot) => {
      const pedidos = snapshot.docs.map((d) =>
        normalizePedidoDoc(d.id, (d.data() || {}) as Record<string, unknown>)
      );

      const novos: Pedido[] = [];
      const prontosAgora: Pedido[] = [];

      if (!firstLoad) {
        for (const change of snapshot.docChanges()) {
          const item = normalizePedidoDoc(
            change.doc.id,
            (change.doc.data() || {}) as Record<string, unknown>
          );
          if (change.type === 'added') {
            novos.push(item);
          } else if (
            change.type === 'modified' &&
            item.pronto &&
            previousReadyMap.get(change.doc.id) !== true
          ) {
            prontosAgora.push(item);
          }
        }
      }

      previousReadyMap.clear();
      for (const p of pedidos) {
        previousReadyMap.set(p.id, p.pronto);
      }

      const visiveis = role === 'conferencia' ? pedidos.filter((p) => !p.entregue) : pedidos;
      onData(visiveis, { novos, prontosAgora }, firstLoad);
      firstLoad = false;
    },
    onError
  );
}

export async function fetchPedidosAtualizados(role: UserRole): Promise<Pedido[]> {
  const colecao = role === 'fabrica' ? 'fabricaPedidos' : 'pedidos';
  const q = role === 'conferencia'
    ? query(collection(db, colecao), where('mLivre', '==', true))
    : query(collection(db, colecao), where('entregue', '==', false));
  const snapshot = await getDocs(q);
  const pedidos = snapshot.docs.map((d) =>
    normalizePedidoDoc(d.id, (d.data() || {}) as Record<string, unknown>)
  );
  return role === 'conferencia' ? pedidos.filter((p) => !p.entregue) : pedidos;
}

export async function fetchDeliveredPedidos(): Promise<Pedido[]> {
  const q = query(collection(db, 'pedidos'), where('entregue', '==', true));
  const snapshot = await getDocs(q);
  return snapshot.docs
    .map((d) => normalizePedidoDoc(d.id, (d.data() || {}) as Record<string, unknown>))
    .sort((a, b) => (b.entregueEm || b.criadoEm || 0) - (a.entregueEm || a.criadoEm || 0));
}

export async function addPedido(data: PedidoWritePayload): Promise<string> {
  const batch = writeBatch(db);
  const ref = doc(collection(db, 'pedidos'));
  batch.set(ref, data);
  if (data.temEstribo) {
    batch.set(doc(db, 'fabricaPedidos', ref.id), buildFabricaMirror(data));
  }
  await batch.commit();
  return ref.id;
}

export async function updatePedido(id: string, data: PedidoWritePayload): Promise<void> {
  const batch = writeBatch(db);
  batch.update(doc(db, 'pedidos', id), data);
  const mirrorRef = doc(db, 'fabricaPedidos', id);
  if (data.temEstribo) {
    batch.set(mirrorRef, buildFabricaMirror(data), { merge: true });
  } else {
    batch.delete(mirrorRef);
  }
  await batch.commit();
}

export async function deletePedido(id: string): Promise<void> {
  const batch = writeBatch(db);
  batch.delete(doc(db, 'pedidos', id));
  batch.delete(doc(db, 'fabricaPedidos', id));
  await batch.commit();
}

export async function updatePedidoStatus(
  id: string,
  data: Record<string, unknown>,
  hasFactoryMirror = true
): Promise<void> {
  const batch = writeBatch(db);
  batch.update(doc(db, 'pedidos', id), data);
  if (hasFactoryMirror) {
    batch.update(doc(db, 'fabricaPedidos', id), data);
  }
  try {
    await batch.commit();
  } catch (err: unknown) {
    const code = (err as { code?: string })?.code;
    if (hasFactoryMirror && code === 'not-found') {
      const fallbackBatch = writeBatch(db);
      fallbackBatch.update(doc(db, 'pedidos', id), data);
      await fallbackBatch.commit();
      return;
    }
    throw err;
  }
}

export async function updateLaunchFields(
  id: string,
  data: Record<string, unknown>
): Promise<void> {
  const batch = writeBatch(db);
  batch.update(doc(db, 'pedidos', id), data);
  await batch.commit();
}

export async function updateItemProgress(
  id: string,
  estribosProntos: boolean[],
  retirarDePronto = false,
  pesoKgPorItem?: Record<string, number>
): Promise<void> {
  const batch = writeBatch(db);
  const payload = {
    ...(retirarDePronto ? { estribosProntos, pronto: false, prontoEm: null } : { estribosProntos }),
    ...(pesoKgPorItem ? { pesoKgPorItem } : {}),
  };
  batch.update(doc(db, 'pedidos', id), payload);
  batch.update(doc(db, 'fabricaPedidos', id), payload);
  await batch.commit();
}
