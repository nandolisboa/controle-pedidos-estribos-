import React, { useEffect, useRef } from 'react';
import type { Pedido } from '../types';
import {
  embalagemDoItem,
  fmtQtd,
  formatarDataISO,
  pacotesDe,
  textoQtdOutro,
} from '../utils';

interface ConfirmLaunchDialogProps {
  open: boolean;
  cliente: string;
  mLivre: boolean;
  dataEntrada: string;
  pretensaoEntrega: string;
  entregaMLivreHora: string;
  urgente: boolean;
  itens: Pedido['itens'];
  obs: string;
  saving: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export const ConfirmLaunchDialog: React.FC<ConfirmLaunchDialogProps> = ({
  open,
  cliente,
  mLivre,
  dataEntrada,
  pretensaoEntrega,
  entregaMLivreHora,
  urgente,
  itens,
  obs,
  saving,
  onCancel,
  onConfirm,
}) => {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    else if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      onCancel={(e) => {
        e.preventDefault();
        if (!saving) onCancel();
      }}
      onClick={(e) => {
        if (e.target === ref.current && !saving) onCancel();
      }}
      className="fixed inset-0 m-auto w-[min(440px,calc(100%-24px))] max-h-[85vh] overflow-auto rounded-xl border border-slate-200 bg-white p-5 text-slate-900 shadow-xl backdrop:bg-slate-950/50"
    >
      <h2 className="text-lg font-bold text-slate-900">Confirmar lançamento</h2>
      <p className="text-sm text-slate-500 mt-1 mb-4">Confira os dados antes de enviar.</p>

      <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm border-t border-slate-100 pt-3">
        <dt className="text-slate-500">Cliente</dt>
        <dd className="font-semibold text-slate-900">{mLivre ? 'M.LIVRE' : cliente}</dd>

        <dt className="text-slate-500">Entrada</dt>
        <dd className="font-semibold text-slate-900 font-mono-num">{formatarDataISO(dataEntrada)}</dd>

        {mLivre ? (
          <>
            <dt className="text-slate-500">Hora limite</dt>
            <dd className="font-semibold text-slate-900 font-mono-num">{entregaMLivreHora || '—'}</dd>
          </>
        ) : pretensaoEntrega ? (
          <>
            <dt className="text-slate-500">Entrega prev.</dt>
            <dd className="font-semibold text-slate-900 font-mono-num">
              {formatarDataISO(pretensaoEntrega)}
            </dd>
          </>
        ) : null}

        {!mLivre && urgente && (
          <>
            <dt className="text-slate-500">Prioridade</dt>
            <dd className="font-bold text-red-600">URGENTE</dd>
          </>
        )}

        <dt className="col-span-2 text-xs font-semibold text-slate-500 pt-2 border-t border-slate-100">
          Itens ({itens.length})
        </dt>
        <dd className="col-span-2 space-y-1 text-xs font-medium text-slate-800">
          {itens.map((item, idx) => {
            const emb = item.tipo !== 'outro' ? embalagemDoItem(item, mLivre) : null;
            return (
              <div key={idx} className="flex justify-between gap-2 py-1 border-b border-slate-50 last:border-0">
                <span>
                  {idx + 1}.{' '}
                  {item.tipo === 'outro'
                    ? item.codigo
                      ? `${item.codigo} · ${item.medida} · ${item.bitola}`
                      : item.material
                    : `${mLivre ? `${emb === 'caixa' ? 'Caixa' : 'Pacote'} ${item.caixaNumero || idx + 1} · ` : ''}${item.medida} · ${item.material} mm`}
                </span>
                <span className="font-mono-num font-semibold shrink-0">
                  {item.tipo === 'outro'
                    ? textoQtdOutro(item)
                    : mLivre
                    ? `${fmtQtd(item.qtd)} est.`
                    : `${fmtQtd(item.qtd)} (${emb === 'caixa' ? 'Caixa' : `${pacotesDe(item.qtd)}`})`}
                </span>
              </div>
            );
          })}
        </dd>

        {obs && (
          <>
            <dt className="text-slate-500 pt-1">Anotações</dt>
            <dd className="text-slate-800 pt-1 break-words">{obs}</dd>
          </>
        )}
      </dl>

      <div className="grid grid-cols-2 gap-2.5 mt-5">
        <button
          type="button"
          disabled={saving}
          onClick={onCancel}
          className="min-h-[44px] px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-60 cursor-pointer"
        >
          Voltar
        </button>
        <button
          type="button"
          disabled={saving}
          onClick={onConfirm}
          className="min-h-[44px] px-4 py-2 text-sm font-bold text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 rounded-lg cursor-pointer"
        >
          {saving ? 'Salvando...' : 'Confirmar'}
        </button>
      </div>
    </dialog>
  );
};

interface SimpleConfirmDialogProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  confirmVariant: 'danger' | 'success' | 'primary';
  busy?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export const SimpleConfirmDialog: React.FC<SimpleConfirmDialogProps> = ({
  open,
  title,
  message,
  confirmLabel,
  confirmVariant,
  busy = false,
  onCancel,
  onConfirm,
}) => {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    else if (!open && dialog.open) dialog.close();
  }, [open]);

  const btnClass =
    confirmVariant === 'danger'
      ? 'bg-red-600 hover:bg-red-700 text-white'
      : confirmVariant === 'success'
      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
      : 'bg-red-600 hover:bg-red-700 text-white';

  return (
    <dialog
      ref={ref}
      onCancel={(e) => {
        e.preventDefault();
        if (!busy) onCancel();
      }}
      onClick={(e) => {
        if (e.target === ref.current && !busy) onCancel();
      }}
      className="fixed inset-0 m-auto w-[min(400px,calc(100%-24px))] rounded-xl border border-slate-200 bg-white p-5 text-slate-900 shadow-xl backdrop:bg-slate-950/50"
    >
      <h2 className="text-lg font-bold text-slate-900">{title}</h2>
      <p className="text-sm text-slate-600 mt-1.5 mb-5">{message}</p>
      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          disabled={busy}
          onClick={onCancel}
          className="min-h-[44px] px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-60 cursor-pointer"
        >
          Voltar
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={onConfirm}
          className={`min-h-[44px] px-4 py-2 text-sm font-bold rounded-lg disabled:opacity-60 cursor-pointer ${btnClass}`}
        >
          {busy ? 'Aguarde...' : confirmLabel}
        </button>
      </div>
    </dialog>
  );
};
