import React, { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import { Bell, ChevronDown, ChevronRight, LogOut, Printer, RefreshCw, Search, WifiOff, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import {
  addPedido,
  deletePedido,
  fetchDeliveredPedidos,
  fetchPedidosAtualizados,
  listenPedidos,
  resolveUserRole,
  signOutUser,
  subscribeAuth,
  updateItemProgress,
  updateLaunchFields,
  updatePedido,
  updatePedidoStatus,
} from './firebase';
import type { Pedido, PedidoWritePayload, StatusFiltro, TabKey, ToastNotice, UserRole } from './types';
import { dataEntradaDoPedido, filtrarPedidos, normalizarBusca, ordenarPedidos, ordenarPedidosMLivre } from './utils';
import { LoginScreen } from './components/LoginScreen';
import { OrderForm, type DraftOrderPayload } from './components/OrderForm';
import { OrderCard } from './components/OrderCard';
import { FactoryView } from './components/FactoryView';
import { ConfirmLaunchDialog, SimpleConfirmDialog } from './components/Dialogs';
import { PdfPreviewModal, PrintSheet } from './components/PrintSheet';

const CLIENTES_CACHE_KEY = 'estribos.clientes';
const AVISOS_KEY = 'estribos.avisos.v1';
type AvisosConfig = { novos: boolean; prontos: boolean; som: boolean };
function lerAvisos(): AvisosConfig {
  try {
    const data = JSON.parse(localStorage.getItem(AVISOS_KEY) || '{}');
    return { novos: data.novos !== false, prontos: data.prontos !== false, som: data.som === true };
  } catch { return { novos: true, prontos: true, som: false }; }
}
let audioAvisos: AudioContext | null = null;
function prepararSom() {
  try {
    audioAvisos ||= new AudioContext();
    void audioAvisos.resume().catch(() => {});
  } catch { /* Som indisponível no navegador */ }
}
function tocarSom() {
  try {
    if (!audioAvisos || audioAvisos.state !== 'running') return;
    const ctx = audioAvisos;
    const agora = ctx.currentTime;
    [0, 0.22].forEach((offset) => {
      const oscilador = ctx.createOscillator();
      const volume = ctx.createGain();
      oscilador.type = 'sine'; oscilador.frequency.value = 660;
      volume.gain.setValueAtTime(0.0001, agora + offset);
      volume.gain.exponentialRampToValueAtTime(0.12, agora + offset + 0.02);
      volume.gain.exponentialRampToValueAtTime(0.0001, agora + offset + 0.18);
      oscilador.connect(volume); volume.connect(ctx.destination);
      oscilador.start(agora + offset); oscilador.stop(agora + offset + 0.19);
    });
  } catch { /* Aviso visual continua disponível */ }
}
async function exibirAvisoNavegador(title: string, body: string, id: string) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return false;
  try {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification(title, { body, tag: `pedido-${id}` });
      return true;
    }
    new Notification(title, { body, tag: `pedido-${id}` });
    return true;
  } catch (error) {
    console.warn('Falha ao exibir notificação do navegador:', error);
    return false;
  }
}

function resumoAviso(p: Pedido): string {
  const nome = p.mLivre ? 'M.LIVRE' : (p.cliente || 'Cliente');
  const marcadores = [p.urgente ? 'URGENTE' : '', p.dataEntrada ? `Data: ${p.dataEntrada.split('-').reverse().join('/')}` : ''].filter(Boolean);
  return [nome, ...marcadores].join(' · ');
}

function readCachedClientes(): string[] {
  try {
    const raw = JSON.parse(localStorage.getItem(CLIENTES_CACHE_KEY) || '[]');
    return Array.isArray(raw) ? raw.filter((n) => typeof n === 'string' && n.trim()) : [];
  } catch {
    return [];
  }
}

function writeCachedClientes(list: string[]) {
  try {
    localStorage.setItem(CLIENTES_CACHE_KEY, JSON.stringify(list));
  } catch {
    // Ignore storage quota errors
  }
}

export default function App() {
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [authError, setAuthError] = useState('');

  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [deliveredPedidos, setDeliveredPedidos] = useState<Pedido[]>([]);
  const [deliveredLoaded, setDeliveredLoaded] = useState(false);
  const [loadingDelivered, setLoadingDelivered] = useState(false);

  const [cachedClientes, setCachedClientes] = useState<string[]>(() => readCachedClientes());
  const [activeTab, setActiveTab] = useState<TabKey>('pedidos');

  const [editingPedido, setEditingPedido] = useState<Pedido | null>(null);
  const [duplicatingPedido, setDuplicatingPedido] = useState<Pedido | null>(null);
  const [pendingLaunch, setPendingLaunch] = useState<DraftOrderPayload | null>(null);
  const [savingOrder, setSavingOrder] = useState(false);

  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [pendingDeleteMLivreDay, setPendingDeleteMLivreDay] = useState<string | null>(null);
  const [atualizandoMLivre, setAtualizandoMLivre] = useState(false);
  const [deletingOrder, setDeletingOrder] = useState(false);

  const [pendingDeliverId, setPendingDeliverId] = useState<string | null>(null);
  const [deliveringOrder, setDeliveringOrder] = useState(false);

  const [filtroBusca, setFiltroBusca] = useState('');
  const deferredBusca = useDeferredValue(filtroBusca);
  const [filtroStatus, setFiltroStatus] = useState<StatusFiltro>('todos');

  const [filtroMLivreBusca, setFiltroMLivreBusca] = useState('');
  const deferredMLivreBusca = useDeferredValue(filtroMLivreBusca);
  const [filtroMLivreData, setFiltroMLivreData] = useState('');

  const [prontosOpen, setProntosOpen] = useState(false);
  const [entreguesOpen, setEntreguesOpen] = useState(false);
  const [mLivreProntosOpen, setMLivreProntosOpen] = useState(false);

  const [isOnline, setIsOnline] = useState(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  const [notifPermission, setNotifPermission] = useState<NotificationPermission | 'unsupported'>(() =>
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported'
  );
  const [avisos, setAvisos] = useState<AvisosConfig>(lerAvisos);
  const avisosRef = useRef(avisos);
  const [avisoTeste, setAvisoTeste] = useState('');
  const mudarAvisos = (chave: keyof AvisosConfig, valor: boolean) => {
    if (chave === 'som' && valor) prepararSom();
    const next = { ...avisosRef.current, [chave]: valor };
    avisosRef.current = next;
    setAvisos(next);
    try { localStorage.setItem(AVISOS_KEY, JSON.stringify(next)); } catch { /* Preferência apenas nesta sessão */ }
  };

  const [toasts, setToasts] = useState<ToastNotice[]>([]);
  const [appError, setAppError] = useState('');
  const [confirmingVisto, setConfirmingVisto] = useState(false);

  const [formResetKey, setFormResetKey] = useState(0);
  const [pdfPreview, setPdfPreview] = useState<{
    pedidos: Pedido[];
    titulo: string;
    emittedAt: number;
  } | null>(null);
  const [printRequestId, setPrintRequestId] = useState(0);
  const [printData, setPrintData] = useState<{
    pedidos: Pedido[];
    titulo: string;
    emittedAt?: number;
  }>({
    pedidos: [],
    titulo: '',
  });

  const errorTimerRef = useRef<number | null>(null);
  const toastTimersRef = useRef<Set<number>>(new Set());

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    void navigator.serviceWorker.register(`${import.meta.env.BASE_URL}service-worker.js`, { scope: import.meta.env.BASE_URL })
      .catch((error) => console.warn('Service worker indisponível:', error));
  }, []);

  useEffect(() => {
    const toastTimers = toastTimersRef.current;
    return () => {
      if (errorTimerRef.current) window.clearTimeout(errorTimerRef.current);
      toastTimers.forEach((id) => window.clearTimeout(id));
      toastTimers.clear();
    };
  }, []);

  const showError = useCallback((msg: string) => {
    setAppError(msg);
    if (errorTimerRef.current) window.clearTimeout(errorTimerRef.current);
    errorTimerRef.current = window.setTimeout(() => setAppError(''), 7000);
  }, []);

  const pushNotice = useCallback((title: string, body: string, id: string, testar = false) => {
    if (avisosRef.current.som) tocarSom();
    if ((document.hidden || testar) && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      void exibirAvisoNavegador(title, body, id).then((ok) => {
        if (testar) setAvisoTeste(ok ? 'Aviso enviado ao navegador. Se não apareceu, confira as permissões e o Não Perturbe.' : 'O navegador não conseguiu exibir o aviso externo. O aviso dentro do app continua disponível.');
      });
    }

    const toastId = `${id}-${Date.now()}`;
    setToasts((prev) => [...prev.slice(-2), { id: toastId, title, body }]);
    const timerId = window.setTimeout(() => {
      toastTimersRef.current.delete(timerId);
      setToasts((prev) => prev.filter((t) => t.id !== toastId));
    }, 6000);
    toastTimersRef.current.add(timerId);
  }, []);

  // Network connectivity listener
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Auth listener
  useEffect(() => {
    const unsub = subscribeAuth((nextUser) => {
      setAuthReady(true);
      if (!nextUser) {
        setUser(null);
        setRole(null);
        setPedidos([]);
        setDeliveredPedidos([]);
        setDeliveredLoaded(false);
        setEditingPedido(null);
        setDuplicatingPedido(null);
        return;
      }
      const resolved = resolveUserRole(nextUser);
      if (!resolved) {
        signOutUser();
        setAuthError('Este usuário não está autorizado neste app.');
        return;
      }
      setAuthError('');
      setUser(nextUser);
      setRole(resolved);
      setActiveTab(resolved === 'fabrica' ? 'fabrica' : resolved === 'conferencia' ? 'mlivre' : 'pedidos');
    });
    return () => unsub();
  }, []);

  // Firestore listener
  useEffect(() => {
    if (!role) return;
    const unsub = listenPedidos(
      role,
      (lista, eventos, isFirstLoad) => {
        setPedidos(lista);
        if (isFirstLoad) return;
        if (role === 'fabrica') {
          if (avisosRef.current.novos) eventos.novos.forEach((p) =>
            pushNotice('Novo pedido para a fábrica', resumoAviso(p), p.id)
          );
        } else if (role === 'lancamento') {
          if (avisosRef.current.prontos) eventos.prontosAgora.forEach((p) =>
            pushNotice('Pedido pronto', resumoAviso(p), p.id)
          );
        }
      },
      (err) => {
        console.error('Erro Firestore:', err);
        showError('Falha ao carregar pedidos. Verifique conexão e permissões.');
      }
    );
    return () => unsub();
  }, [role, pushNotice, showError]);

  // Print trigger & cleanup
  useEffect(() => {
    if (!printRequestId || !printData.pedidos.length) return;
    let raf1 = 0;
    let raf2 = 0;
    raf1 = window.requestAnimationFrame(() => {
      raf2 = window.requestAnimationFrame(() => {
        window.print();
      });
    });
    return () => {
      window.cancelAnimationFrame(raf1);
      window.cancelAnimationFrame(raf2);
    };
  }, [printRequestId, printData.pedidos]);

  useEffect(() => {
    const handleAfterPrint = () => setPrintData({ pedidos: [], titulo: '' });
    window.addEventListener('afterprint', handleAfterPrint);
    return () => window.removeEventListener('afterprint', handleAfterPrint);
  }, []);

  const loadDeliveredIfNeeded = useCallback(async () => {
    if (role !== 'lancamento' || deliveredLoaded || loadingDelivered) return;
    setLoadingDelivered(true);
    try {
      const lista = await fetchDeliveredPedidos();
      setDeliveredPedidos(lista);
      setDeliveredLoaded(true);
    } catch (err) {
      console.error('Erro ao carregar entregues:', err);
      showError('Não foi possível carregar os pedidos entregues.');
    } finally {
      setLoadingDelivered(false);
    }
  }, [role, deliveredLoaded, loadingDelivered, showError]);

  useEffect(() => {
    if (role !== 'lancamento') return;
    if (
      entreguesOpen ||
      filtroStatus === 'entregue' ||
      deferredBusca.trim().length > 0 ||
      deferredMLivreBusca.trim().length > 0 ||
      filtroMLivreData !== ''
    ) {
      loadDeliveredIfNeeded();
    }
  }, [
    role,
    entreguesOpen,
    filtroStatus,
    deferredBusca,
    deferredMLivreBusca,
    filtroMLivreData,
    loadDeliveredIfNeeded,
  ]);

  // Derived lists
  const allPedidos = useMemo(() => {
    if (!deliveredPedidos.length) return pedidos;
    const seen = new Set(pedidos.map((p) => p.id));
    return [...pedidos, ...deliveredPedidos.filter((p) => !seen.has(p.id))];
  }, [pedidos, deliveredPedidos]);

  const clientesDisponiveis = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const nome of [...cachedClientes, ...allPedidos.map((p) => p.cliente)]) {
      const clean = String(nome || '').trim();
      if (!clean || clean === 'M.LIVRE') continue;
      const key = clean.toLocaleLowerCase('pt-BR');
      if (!seen.has(key)) {
        seen.add(key);
        out.push(clean);
      }
    }
    return out.sort((a, b) => a.localeCompare(b, 'pt-BR'));
  }, [cachedClientes, allPedidos]);

  const sortedAll = useMemo(() => ordenarPedidos(allPedidos), [allPedidos]);

  const { ativosNormais, prontosNormais, entreguesNormais } = useMemo(() => {
    const normais = filtrarPedidos(
      sortedAll.filter((p) => !p.mLivre),
      deferredBusca,
      filtroStatus
    );
    return {
      ativosNormais: normais.filter((p) => !p.entregue && !p.pronto),
      prontosNormais: normais.filter((p) => !p.entregue && p.pronto),
      entreguesNormais: normais
        .filter((p) => p.entregue)
        .sort((a, b) => (b.entregueEm || b.criadoEm || 0) - (a.entregueEm || a.criadoEm || 0)),
    };
  }, [sortedAll, deferredBusca, filtroStatus]);

  const { ativosMLivre, prontosMLivre } = useMemo(() => {
    const termo = normalizarBusca(deferredMLivreBusca);
    const ml = sortedAll.filter((p) => {
      if (!p.mLivre) return false;
      if (filtroMLivreData && dataEntradaDoPedido(p) !== filtroMLivreData) return false;
      if (termo) {
        const matchObs = normalizarBusca(p.obs).includes(termo);
        const matchHora = normalizarBusca(p.entregaMLivre).includes(termo);
        const matchItem = p.itens.some(
          (i) => normalizarBusca(i.medida).includes(termo) || normalizarBusca(i.material).includes(termo)
        );
        if (!matchObs && !matchHora && !matchItem) return false;
      }
      return true;
    });
    return {
      ativosMLivre: ordenarPedidosMLivre(ml.filter((p) => !p.entregue && !p.pronto)),
      prontosMLivre: ordenarPedidosMLivre(ml.filter((p) => !p.entregue && p.pronto)),
    };
  }, [sortedAll, deferredMLivreBusca, filtroMLivreData]);

  const prontosMLivrePorDia = useMemo(() => {
    const porDia = new Map<string, Pedido[]>();
    for (const pedido of prontosMLivre) {
      const dia = dataEntradaDoPedido(pedido);
      porDia.set(dia, [...(porDia.get(dia) || []), pedido]);
    }
    return [...porDia.entries()].sort(([a], [b]) => b.localeCompare(a));
  }, [prontosMLivre]);

  const fabricaMLivrePendentesCount = useMemo(
    () =>
      pedidos.filter(
        (p) => p.mLivre && !p.entregue && !p.pronto && p.itens.some((i) => i.tipo !== 'outro')
      ).length,
    [pedidos]
  );

  const gruposMLivreProntosNaoVistos = useMemo(() => {
    const map = new Map<string, Pedido[]>();
    for (const p of pedidos) {
      if (!p.mLivre) continue;
      const dia = dataEntradaDoPedido(p);
      const arr = map.get(dia);
      if (arr) arr.push(p);
      else map.set(dia, [p]);
    }
    const grupos: Pedido[] = [];
    for (const ps of map.values()) {
      const hasUndelivered = ps.some((p) => !p.entregue);
      const allReady = ps.length > 0 && ps.every((p) => p.pronto);
      const anyUnseen = ps.some(
        (p) => !p.mLivreVisto || (Number(p.prontoEm) > 0 && Number(p.mLivreVistoEm || 0) < Number(p.prontoEm))
      );
      if (hasUndelivered && allReady && anyUnseen) {
        grupos.push(...ps);
      }
    }
    return grupos;
  }, [pedidos]);

  const hasMLivreVistoPendente = gruposMLivreProntosNaoVistos.length > 0;

  // Handlers
  const handleConfirmLaunch = async () => {
    if (!pendingLaunch) return;
    setSavingOrder(true);
    try {
      const anterior = pendingLaunch.editingId
        ? allPedidos.find((x) => x.id === pendingLaunch.editingId) || null
        : null;

      const itensSalvos = pendingLaunch.itens.map((i) => ({ ...i }));
      const somenteEstoque = itensSalvos.length > 0 && itensSalvos.every((i) => i.tipo === 'outro');
      const estribosAntes = (anterior?.itens || []).filter((i) => i.tipo !== 'outro');
      const estribosDepois = itensSalvos.filter((i) => i.tipo !== 'outro');

      const mudouEstribos =
        estribosAntes.length !== estribosDepois.length ||
        estribosAntes.some((a, idx) => {
          const b = estribosDepois[idx];
          return a.medida !== b.medida || a.material !== b.material || a.qtd !== b.qtd;
        });

      const estribosProntos = estribosDepois.map(
        (item, idx) =>
          !mudouEstribos &&
          (anterior?.estribosProntos?.[idx] === true ||
            (!Array.isArray(anterior?.estribosProntos) && item.pronto === true))
      );

      let eIdx = 0;
      for (const item of itensSalvos) {
        if (item.tipo !== 'outro') {
          item.pronto = estribosProntos[eIdx++] === true;
        }
      }

      const todosEstribosProntos =
        estribosDepois.length > 0 &&
        estribosProntos.length === estribosDepois.length &&
        estribosProntos.every(Boolean);

      const agora = Date.now();
      const emailAtual = user?.email || '';
      const dados: PedidoWritePayload = {
        cliente: pendingLaunch.mLivre ? 'M.LIVRE' : pendingLaunch.cliente,
        numeroPedido: anterior?.numeroPedido || '',
        kg: anterior?.kg ?? 0,
        pesoKgPorItem: anterior?.mLivre && !mudouEstribos ? anterior.pesoKgPorItem || {} : {},
        ...(pendingLaunch.mLivre
          ? {
              mLivre: true,
              entregaMLivre: pendingLaunch.entregaMLivreHora,
              mLivreVisto: Boolean(anterior?.mLivreVisto && !mudouEstribos),
            }
          : {}),
        criadoEm: anterior?.criadoEm || agora,
        criadoPor: anterior?.criadoPor || emailAtual,
        atualizadoEm: agora,
        atualizadoPor: emailAtual,
        dataEntrada: pendingLaunch.dataEntrada,
        pretensaoEntrega: pendingLaunch.mLivre ? '' : pendingLaunch.pretensaoEntrega,
        urgente: pendingLaunch.mLivre ? false : pendingLaunch.urgente,
        obs: pendingLaunch.obs,
        pronto: somenteEstoque || todosEstribosProntos,
        estribosProntos,
        temEstribo: estribosDepois.length > 0,
        prontoEm: somenteEstoque
          ? anterior?.prontoEm || agora
          : todosEstribosProntos
          ? anterior?.pronto && !mudouEstribos
            ? anterior.prontoEm || agora
            : agora
          : null,
        entregue: anterior?.entregue === true,
        entregueEm: anterior?.entregueEm || null,
        itens: itensSalvos,
      };

      if (pendingLaunch.editingId) {
        await updatePedido(pendingLaunch.editingId, dados);
        if (anterior?.entregue && deliveredLoaded) {
          const editado: Pedido = {
            ...dados,
            id: pendingLaunch.editingId,
            mLivre: Boolean(dados.mLivre),
            entregaMLivre: dados.entregaMLivre || '',
            mLivreVisto: Boolean(dados.mLivreVisto),
          };
          setDeliveredPedidos((prev) =>
            prev.map((x) => (x.id === pendingLaunch.editingId ? editado : x))
          );
        }
      } else {
        await addPedido(dados);
      }

      if (!pendingLaunch.mLivre) {
        const nome = pendingLaunch.cliente.trim();
        if (nome && !cachedClientes.some((c) => c.toLowerCase() === nome.toLowerCase())) {
          const updated = [...cachedClientes, nome].sort((a, b) => a.localeCompare(b, 'pt-BR'));
          setCachedClientes(updated);
          writeCachedClientes(updated);
        }
      }

      setPendingLaunch(null);
      setEditingPedido(null);
      setDuplicatingPedido(null);
      setFormResetKey((k) => k + 1);
    } catch (err) {
      console.error('Erro ao salvar:', err);
      showError('Não foi possível salvar o pedido no Firebase.');
    } finally {
      setSavingOrder(false);
    }
  };

  const handleEditPedido = useCallback(
    (id: string) => {
      const p = allPedidos.find((x) => x.id === id);
      if (!p) return;
      setDuplicatingPedido(null);
      setEditingPedido(p);
      setActiveTab(p.mLivre ? 'mlivre' : 'pedidos');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [allPedidos]
  );

  const handleDuplicatePedido = useCallback(
    (id: string) => {
      const p = allPedidos.find((x) => x.id === id);
      if (!p) return;
      setEditingPedido(null);
      setDuplicatingPedido(p);
      setActiveTab(p.mLivre ? 'mlivre' : 'pedidos');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [allPedidos]
  );

  const handlePdfPedido = useCallback(
    (id: string) => {
      const p = allPedidos.find((x) => x.id === id);
      if (!p) return;
      setPdfPreview({ pedidos: [p], titulo: 'Pedido de Produção', emittedAt: Date.now() });
    },
    [allPedidos]
  );

  const handlePdfProducao = () => {
    const lista = sortedAll.filter((p) => !p.mLivre && !p.entregue && !p.pronto);
    if (!lista.length) {
      showError('Nenhum pedido em produção para imprimir.');
      return;
    }
    setPdfPreview({ pedidos: lista, titulo: 'Pedidos em Produção', emittedAt: Date.now() });
  };

  const handlePdfGeral = () => {
    const lista = sortedAll.filter((p) => !p.mLivre && !p.entregue);
    if (!lista.length) {
      showError('Nenhum pedido ativo para imprimir.');
      return;
    }
    setPdfPreview({ pedidos: lista, titulo: 'Relação de Pedidos', emittedAt: Date.now() });
  };

  const handlePdfFactory = (lista: Pedido[], mLivre: boolean) => {
    if (!lista.length) {
      showError('Nenhum pedido em produção para imprimir.');
      return;
    }
    setPdfPreview({
      pedidos: lista,
      titulo: mLivre ? 'Pedidos em Produção · M.Livre' : 'Pedidos em Produção',
      emittedAt: Date.now(),
    });
  };

  const atualizarPedidos = async () => {
    if (!role || atualizandoMLivre) return;
    setAtualizandoMLivre(true);
    try {
      const atualizados = await fetchPedidosAtualizados(role);
      setPedidos(atualizados);
    } catch (err) {
      console.error('Erro ao atualizar pedidos:', err);
      showError('Não foi possível atualizar os pedidos. Verifique a conexão e tente novamente.');
    } finally {
      setAtualizandoMLivre(false);
    }
  };

  const handlePdfMLivre = () => {
    const lista = [...ativosMLivre, ...prontosMLivre];
    if (!lista.length) {
      showError('Nenhum pedido M.Livre ativo para imprimir.');
      return;
    }
    setPdfPreview({ pedidos: lista, titulo: 'Relação de Pedidos · M.Livre', emittedAt: Date.now() });
  };

  const handleDeleteMLivreDayConfirm = async () => {
    if (!pendingDeleteMLivreDay) return;
    const ids = allPedidos
      .filter(
        (p) =>
          p.mLivre &&
          p.pronto &&
          !p.entregue &&
          dataEntradaDoPedido(p) === pendingDeleteMLivreDay
      )
      .map((p) => p.id);
    if (!ids.length) {
      setPendingDeleteMLivreDay(null);
      return;
    }
    setDeletingOrder(true);
    try {
      await Promise.all(ids.map((id) => deletePedido(id)));
      setDeliveredPedidos((prev) => prev.filter((p) => !ids.includes(p.id)));
      if (ids.includes(editingPedido?.id || '')) setEditingPedido(null);
      if (ids.includes(duplicatingPedido?.id || '')) setDuplicatingPedido(null);
      setPendingDeleteMLivreDay(null);
    } catch (err) {
      console.error('Erro ao excluir pedidos M.Livre do dia:', err);
      showError('Não foi possível apagar todos os pedidos prontos desse dia.');
    } finally {
      setDeletingOrder(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!pendingDeleteId) return;
    setDeletingOrder(true);
    try {
      await deletePedido(pendingDeleteId);
      setDeliveredPedidos((prev) => prev.filter((p) => p.id !== pendingDeleteId));
      if (editingPedido?.id === pendingDeleteId) setEditingPedido(null);
      if (duplicatingPedido?.id === pendingDeleteId) setDuplicatingPedido(null);
      setPendingDeleteId(null);
    } catch (err) {
      console.error('Erro ao excluir:', err);
      showError('Não foi possível excluir o pedido.');
    } finally {
      setDeletingOrder(false);
    }
  };

  const handleDeliverConfirm = async () => {
    if (!pendingDeliverId) return;
    const pedido = pedidos.find((p) => p.id === pendingDeliverId);
    if (!pedido) return;
    setDeliveringOrder(true);
    try {
      const ts = Date.now();
      await updatePedidoStatus(
        pendingDeliverId,
        { entregue: true, entregueEm: ts },
        pedido.itens.some((i) => i.tipo !== 'outro')
      );
      if (deliveredLoaded) {
        setDeliveredPedidos((prev) => [
          { ...pedido, entregue: true, entregueEm: ts },
          ...prev.filter((p) => p.id !== pedido.id),
        ]);
      }
      setPendingDeliverId(null);
    } catch (err) {
      console.error('Erro ao marcar entrega:', err);
      showError('Não foi possível registrar a entrega.');
    } finally {
      setDeliveringOrder(false);
    }
  };

  const handleConfirmarVistoMLivre = async () => {
    if (!gruposMLivreProntosNaoVistos.length) return;
    setConfirmingVisto(true);
    try {
      const ts = Date.now();
      await Promise.all(
        gruposMLivreProntosNaoVistos.map((p) =>
          updateLaunchFields(p.id, { mLivreVisto: true, mLivreVistoEm: ts })
        )
      );
    } catch (err) {
      console.error('Erro ao confirmar visto M.Livre:', err);
      showError('Não foi possível confirmar o aviso.');
    } finally {
      setConfirmingVisto(false);
    }
  };

  const handleToggleFactoryItem = useCallback(
    async (pedidoId: string, itemIdx: number, pesoKg?: number) => {
      const pedido = pedidos.find((p) => p.id === pedidoId);
      if (!pedido) return;
      const estribos = pedido.itens.filter((i) => i.tipo !== 'outro');
      if (!estribos[itemIdx]) return;
      const estribosProntos = estribos.map((item, idx) =>
        idx === itemIdx
          ? !Boolean(pedido.estribosProntos?.[idx] ?? item.pronto)
          : Boolean(pedido.estribosProntos?.[idx] ?? item.pronto)
      );
      const retirarDePronto = pedido.pronto && !estribosProntos.every(Boolean);
      try {
        const pesoKgPorItem = pesoKg !== undefined
          ? { ...(pedido.pesoKgPorItem || {}), [String(itemIdx)]: pesoKg }
          : undefined;
        await updateItemProgress(pedidoId, estribosProntos, retirarDePronto, pesoKgPorItem);
      } catch (err) {
        console.error('Erro ao atualizar item:', err);
        showError('Não foi possível atualizar o item.');
      }
    },
    [pedidos, showError]
  );

  const handleConfirmOrderReady = useCallback(
    async (pedidoId: string) => {
      const pedido = pedidos.find((p) => p.id === pedidoId);
      if (!pedido || pedido.pronto) return;
      const estribos = pedido.itens.filter((i) => i.tipo !== 'outro');
      const marcados = pedido.estribosProntos || estribos.map((i) => i.pronto === true);
      if (!estribos.length || marcados.length !== estribos.length || !marcados.every(Boolean)) return;
      try {
        await updatePedidoStatus(pedidoId, { pronto: true, prontoEm: Date.now() });
      } catch (err) {
        console.error('Erro ao confirmar pedido pronto:', err);
        showError('Não foi possível confirmar o pedido.');
      }
    },
    [pedidos, showError]
  );

  const handleRequestNotifications = async () => {
    if (!('Notification' in window)) return;
    try {
      if ('serviceWorker' in navigator) {
        await navigator.serviceWorker.register(`${import.meta.env.BASE_URL}service-worker.js`, { scope: import.meta.env.BASE_URL });
        await navigator.serviceWorker.ready;
      }
      const perm = await Notification.requestPermission();
      setNotifPermission(perm);
      if (perm !== 'granted') setAvisoTeste('Permissão não concedida. Confira as configurações de notificações do Chrome.');
    } catch {
      setAvisoTeste('Não foi possível ativar os avisos neste navegador.');
    }
  };
  const handleTestarAvisos = () => {
    if (avisos.som) prepararSom();
    setAvisoTeste(notifPermission === 'granted'
      ? 'Teste enviado: confira também as notificações do aparelho.'
      : 'Teste do aviso interno. Para o aviso do navegador, ative a permissão.');
    pushNotice('Teste de aviso', 'Exemplo: pedido de Cliente · URGENTE', 'teste', true);
  };

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8f9fa]">
        <div className="text-sm font-semibold text-slate-500">Carregando...</div>
      </div>
    );
  }

  if (!user || !role) {
    return <LoginScreen externalError={authError} />;
  }

  const pendingDeletePedido = pendingDeleteId ? allPedidos.find((p) => p.id === pendingDeleteId) : null;
  const pendingDeliverPedido = pendingDeliverId ? pedidos.find((p) => p.id === pendingDeliverId) : null;

  const hasSearch = deferredBusca.trim().length > 0;
  const showActiveSection =
    filtroStatus === 'todos' || filtroStatus === 'urgente' || filtroStatus === 'produzindo';
  const showProntosSection =
    filtroStatus === 'todos' || filtroStatus === 'pronto' || (hasSearch && prontosNormais.length > 0);
  const showEntreguesSection =
    filtroStatus === 'todos' || filtroStatus === 'entregue' || (hasSearch && entreguesNormais.length > 0);
  const showProntosOpen =
    prontosOpen ||
    filtroStatus === 'pronto' ||
    (hasSearch && ativosNormais.length === 0 && prontosNormais.length > 0);
  const showEntreguesOpen =
    entreguesOpen ||
    filtroStatus === 'entregue' ||
    (hasSearch && ativosNormais.length === 0 && prontosNormais.length === 0 && entreguesNormais.length > 0);

  const hasMLivreFilter = deferredMLivreBusca.trim().length > 0 || filtroMLivreData !== '';
  const showMLivreProntosOpen =
    mLivreProntosOpen || (hasMLivreFilter && ativosMLivre.length === 0 && prontosMLivre.length > 0);

  return (
    <>
      <div id="appRoot" className="min-h-screen flex flex-col bg-[#f8f9fa]">
        {/* Top bar — clean 3-zone contract */}
        <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-2.5 sm:py-0 sm:h-16 flex flex-wrap sm:flex-nowrap items-center justify-between gap-y-2 gap-x-3 sm:gap-8">
            <span className="order-1 text-base sm:text-xl font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
              ARAMES <span className="text-red-600">BRASIL</span>
            </span>

            <nav
              aria-label="Navegação principal"
              className="order-3 sm:order-2 w-full sm:w-auto grid grid-cols-2 sm:flex items-center gap-1 p-1 bg-slate-100 rounded-lg"
            >
              {role === 'conferencia' ? (
                <span className="px-4 py-2 text-sm font-bold text-yellow-900">Conferência M.Livre · Somente leitura</span>
              ) : role === 'lancamento' ? (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingPedido(null);
                      setDuplicatingPedido(null);
                      setActiveTab('pedidos');
                    }}
                    className={`px-3 sm:px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 text-center cursor-pointer ${
                      activeTab === 'pedidos'
                        ? 'bg-white text-red-600 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Lançamentos
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingPedido(null);
                      setDuplicatingPedido(null);
                      setActiveTab('mlivre');
                    }}
                    className={`px-3 sm:px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 inline-flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeTab === 'mlivre'
                        ? 'bg-yellow-100 text-yellow-900 shadow-xs'
                        : hasMLivreVistoPendente
                        ? 'bg-emerald-100 text-emerald-900'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    M.Livre
                    {hasMLivreVistoPendente && (
                      <span className="font-mono-num text-[11px] font-bold">
                        ({gruposMLivreProntosNaoVistos.length})
                      </span>
                    )}
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => setActiveTab('fabrica')}
                    className={`px-3 sm:px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 text-center cursor-pointer ${
                      activeTab === 'fabrica'
                        ? 'bg-white text-red-600 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Fábrica
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('fabrica-mlivre')}
                    className={`px-3 sm:px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 inline-flex items-center justify-center gap-1.5 cursor-pointer ${
                      activeTab === 'fabrica-mlivre'
                        ? 'bg-yellow-100 text-yellow-900 shadow-xs'
                        : fabricaMLivrePendentesCount > 0
                        ? 'bg-amber-100 text-amber-900'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Fábrica M.Livre
                    {fabricaMLivrePendentesCount > 0 && (
                      <span className="font-mono-num text-[11px] font-bold">
                        ({fabricaMLivrePendentesCount})
                      </span>
                    )}
                  </button>
                </>
              )}
            </nav>

            <button
              type="button"
              onClick={() => signOutUser()}
              className="order-2 sm:order-3 min-h-[38px] sm:min-h-[40px] px-3 py-1.5 sm:py-2 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sair
            </button>
          </div>
        </header>

        <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 py-5 space-y-5">
          {/* Offline warning only when disconnected */}
          {!isOnline && (
            <div
              role="status"
              className="flex items-center gap-2 px-4 py-2.5 bg-amber-50 border border-amber-300 rounded-xl text-xs font-semibold text-amber-900"
            >
              <WifiOff className="w-4 h-4 shrink-0" />
              <span>Sem conexão com a internet. Os dados em cache continuam visíveis e serão sincronizados ao reconectar.</span>
            </div>
          )}

          {role !== 'conferencia' && <details className="bg-white border border-slate-200 rounded-xl text-sm">
            <summary className="flex items-center gap-2 px-4 py-3 font-bold text-slate-700 cursor-pointer">
              <Bell className="w-4 h-4 text-red-600" /> Avisos de pedidos
            </summary>
            <div className="px-4 pb-4 space-y-3 text-slate-700">
              <p className="text-xs">Grátis neste aparelho. Mantenha o aplicativo aberto para receber avisos; em segundo plano, o navegador pode limitar a entrega.</p>
              <p className="text-xs" role="status">
                {notifPermission === 'granted' ? 'Notificações do navegador permitidas.' : notifPermission === 'denied' ? 'Notificações bloqueadas. Libere nas configurações do navegador.' : notifPermission === 'unsupported' ? 'Este navegador não oferece notificações. Os avisos internos continuam disponíveis.' : 'Ative a permissão para receber avisos do navegador.'}
              </p>
              {notifPermission === 'default' && <button type="button" onClick={handleRequestNotifications} className="px-3 py-2 text-xs font-bold text-white bg-red-600 rounded-md cursor-pointer">Ativar notificações</button>}
              <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs font-medium">
                {role === 'fabrica' && <label className="flex items-center gap-2"><input type="checkbox" checked={avisos.novos} onChange={e => mudarAvisos('novos', e.target.checked)} /> Avisar novos pedidos</label>}
                {role === 'lancamento' && <label className="flex items-center gap-2"><input type="checkbox" checked={avisos.prontos} onChange={e => mudarAvisos('prontos', e.target.checked)} /> Avisar pedidos prontos</label>}
                <label className="flex items-center gap-2"><input type="checkbox" checked={avisos.som} onChange={e => mudarAvisos('som', e.target.checked)} /> Som opcional</label>
              </div>
              <p className="text-xs text-slate-500">Para habilitar o som após abrir a página, toque em Testar aviso. O aparelho não deve estar no silencioso.</p>
              <button type="button" onClick={handleTestarAvisos} className="px-3 py-2 text-xs font-bold text-red-700 border border-red-300 rounded-md cursor-pointer">Testar aviso</button>
              {avisoTeste && <p role="status" className="text-xs">{avisoTeste}</p>}
            </div>
          </details>}

          {/* M.Livre ready acknowledgement bar */}
          {role === 'lancamento' && hasMLivreVistoPendente && (
            <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-emerald-50 border border-emerald-300 rounded-xl text-sm">
              <span className="font-bold text-emerald-900">
                Pedidos M.Livre concluídos ({gruposMLivreProntosNaoVistos.length}).
              </span>
              <button
                type="button"
                disabled={confirmingVisto}
                onClick={handleConfirmarVistoMLivre}
                className="min-h-[38px] px-4 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 rounded-lg cursor-pointer"
              >
                {confirmingVisto ? 'Confirmando...' : 'Confirmar visto'}
              </button>
            </div>
          )}

          {/* Role: Lançamento */}
          {(role === 'lancamento' || role === 'conferencia') && (activeTab === 'pedidos' || activeTab === 'mlivre') && (
            <>
              {role === 'lancamento' && <OrderForm
                mLivre={activeTab === 'mlivre'}
                resetKey={formResetKey}
                clientesDisponiveis={clientesDisponiveis}
                editingPedido={
                  editingPedido && Boolean(editingPedido.mLivre) === (activeTab === 'mlivre')
                    ? editingPedido
                    : null
                }
                duplicatingPedido={
                  !editingPedido &&
                  duplicatingPedido &&
                  Boolean(duplicatingPedido.mLivre) === (activeTab === 'mlivre')
                    ? duplicatingPedido
                    : null
                }
                onCancelEdit={() => {
                  setEditingPedido(null);
                  setFormResetKey((k) => k + 1);
                }}
                onCancelDuplicate={() => {
                  setDuplicatingPedido(null);
                  setFormResetKey((k) => k + 1);
                }}
                onRequestLaunch={(payload) => setPendingLaunch(payload)}
              />}

              {activeTab === 'pedidos' ? (
                <section className="space-y-4 pt-2">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <h2 className="text-lg font-extrabold text-slate-900">Pedidos lançados</h2>
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={atualizarPedidos}
                        disabled={atualizandoMLivre}
                        className="min-h-[42px] px-3.5 py-2 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer disabled:opacity-60 disabled:cursor-wait"
                        title="Buscar pedidos novamente"
                      >
                        <RefreshCw className={`w-4 h-4 text-slate-600 ${atualizandoMLivre ? 'animate-spin' : ''}`} />
                        {atualizandoMLivre ? 'Atualizando...' : 'Atualizar'}
                      </button>
                      <button
                        type="button"
                        onClick={handlePdfProducao}
                        className="min-h-[42px] px-3.5 py-2 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
                      >
                        <Printer className="w-4 h-4 text-slate-600" />
                        PDF em produção
                      </button>
                      <button
                        type="button"
                        onClick={handlePdfGeral}
                        className="min-h-[42px] px-3.5 py-2 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
                      >
                        <Printer className="w-4 h-4 text-slate-600" />
                        PDF completo
                      </button>
                    </div>
                  </div>

                  {/* Filter bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
                    <div className="relative flex-1 min-w-0">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="search"
                        value={filtroBusca}
                        onChange={(e) => setFiltroBusca(e.target.value)}
                        placeholder="Buscar cliente, medida ou bitola"
                        className="w-full min-h-[42px] pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <select
                        aria-label="Filtrar por status"
                        value={filtroStatus}
                        onChange={(e) => setFiltroStatus(e.target.value as StatusFiltro)}
                        className="flex-1 sm:flex-none min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-200 focus:border-red-600"
                      >
                        <option value="todos">Todos os status</option>
                        <option value="urgente">Urgentes</option>
                        <option value="produzindo">Produzindo</option>
                        <option value="pronto">Prontos</option>
                        <option value="entregue">Entregues</option>
                      </select>
                      {(filtroBusca || filtroStatus !== 'todos') && (
                        <button
                          type="button"
                          onClick={() => {
                            setFiltroBusca('');
                            setFiltroStatus('todos');
                          }}
                          className="min-h-[42px] px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shrink-0 cursor-pointer"
                        >
                          Limpar
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Lazy collapsible Ready section */}
                  {showProntosSection && (
                    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                      <button
                        type="button"
                        onClick={() => setProntosOpen((prev) => !prev)}
                        aria-expanded={showProntosOpen}
                        className="w-full min-h-[48px] px-4 py-3 flex items-center justify-between text-sm font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          {showProntosOpen ? (
                            <ChevronDown className="w-4 h-4" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                          Pedidos prontos
                        </span>
                        <span className="font-mono-num text-xs font-bold text-slate-600">
                          {prontosNormais.length}
                        </span>
                      </button>
                      {showProntosOpen && (
                        <div className="p-3 pt-1 border-t border-slate-100 space-y-3">
                          {prontosNormais.length ? (
                            prontosNormais.map((p) => (
                              <OrderCard
                                key={p.id}
                                pedido={p}
                                canEdit
                                onEdit={handleEditPedido}
                                onDuplicate={handleDuplicatePedido}
                                onPdf={handlePdfPedido}
                                onDelete={setPendingDeleteId}
                              />
                            ))
                          ) : (
                            <p className="text-center text-sm text-slate-500 py-4">
                              Nenhum pedido pronto.
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Active orders */}
                  {showActiveSection && (
                    <div className="space-y-3">
                      {ativosNormais.length ? (
                        ativosNormais.map((p) => (
                          <OrderCard
                            key={p.id}
                            pedido={p}
                            canEdit
                            onEdit={handleEditPedido}
                            onDuplicate={handleDuplicatePedido}
                            onPdf={handlePdfPedido}
                            onDelete={setPendingDeleteId}
                          />
                        ))
                      ) : (
                        <p className="text-center text-sm text-slate-500 py-8 bg-white border border-slate-200 rounded-xl">
                          Nenhum pedido em andamento.
                        </p>
                      )}
                    </div>
                  )}

                  {/* Lazy collapsible Delivered section */}
                  {showEntreguesSection && (
                    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                      <button
                        type="button"
                        onClick={() => setEntreguesOpen((prev) => !prev)}
                        aria-expanded={showEntreguesOpen}
                        className="w-full min-h-[48px] px-4 py-3 flex items-center justify-between text-sm font-bold text-emerald-800 hover:bg-slate-50 cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          {showEntreguesOpen ? (
                            <ChevronDown className="w-4 h-4" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                          Pedidos entregues
                        </span>
                        <span className="font-mono-num text-xs font-bold text-emerald-700">
                          {deliveredLoaded ? entreguesNormais.length : '…'}
                        </span>
                      </button>
                      {showEntreguesOpen && (
                        <div className="p-3 pt-1 border-t border-slate-100 space-y-3">
                          {loadingDelivered ? (
                            <p className="text-center text-sm text-slate-500 py-4">
                              Carregando pedidos entregues...
                            </p>
                          ) : entreguesNormais.length ? (
                            entreguesNormais.map((p) => (
                              <OrderCard
                                key={p.id}
                                pedido={p}
                                canEdit
                                onEdit={handleEditPedido}
                                onDuplicate={handleDuplicatePedido}
                                onPdf={handlePdfPedido}
                                onDelete={setPendingDeleteId}
                              />
                            ))
                          ) : (
                            <p className="text-center text-sm text-slate-500 py-4">
                              Nenhum pedido entregue.
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </section>
              ) : (
                /* M.Livre Orders List */
                <section className="space-y-4 pt-2">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg font-extrabold text-yellow-950 border-l-4 border-yellow-400 pl-2.5">
                        M.Livre em produção
                      </h2>
                      <span className="font-mono-num text-xs font-bold text-yellow-800">
                        ({ativosMLivre.length})
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={atualizarPedidos}
                        disabled={atualizandoMLivre}
                        className="min-h-[42px] px-4 py-2 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer disabled:opacity-60 disabled:cursor-wait"
                        title="Buscar pedidos novamente e reorganizar a lista"
                      >
                        <RefreshCw className={`w-4 h-4 text-slate-600 ${atualizandoMLivre ? 'animate-spin' : ''}`} />
                        {atualizandoMLivre ? 'Atualizando...' : 'Atualizar'}
                      </button>
                      <button
                        type="button"
                        onClick={handlePdfMLivre}
                        className="min-h-[42px] px-4 py-2 inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
                      >
                        <Printer className="w-4 h-4 text-slate-600" />
                        PDF M.Livre
                      </button>
                    </div>
                  </div>

                  {/* M.Livre Filter bar */}
                  <div className="flex flex-wrap items-center gap-2.5">
                    <div className="relative flex-1 min-w-[200px]">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="search"
                        value={filtroMLivreBusca}
                        onChange={(e) => setFiltroMLivreBusca(e.target.value)}
                        placeholder="Buscar medida, bitola ou observação"
                        className="w-full min-h-[42px] pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-200 focus:border-yellow-500"
                      />
                    </div>
                    <input
                      type="date"
                      aria-label="Filtrar M.Livre por data"
                      value={filtroMLivreData}
                      onChange={(e) => setFiltroMLivreData(e.target.value)}
                      className="min-h-[42px] px-3 py-2 text-sm font-mono-num bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-200 focus:border-yellow-500"
                    />
                    {hasMLivreFilter && (
                      <button
                        type="button"
                        onClick={() => {
                          setFiltroMLivreBusca('');
                          setFiltroMLivreData('');
                        }}
                        className="min-h-[42px] px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
                      >
                        Limpar
                      </button>
                    )}
                  </div>

                  <div className="space-y-3">
                    {ativosMLivre.length ? (
                      ativosMLivre.map((p) => (
                        <OrderCard
                          key={p.id}
                          pedido={p}
                          canEdit={role === 'lancamento'}
                          onEdit={handleEditPedido}
                          onDuplicate={handleDuplicatePedido}
                          onPdf={handlePdfPedido}
                          onDelete={setPendingDeleteId}
                        />
                      ))
                    ) : (
                      <p className="text-center text-sm text-slate-500 py-8 bg-white border border-slate-200 rounded-xl">
                        Nenhum pedido M.Livre em produção.
                      </p>
                    )}
                  </div>

                  <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                    <button
                      type="button"
                      onClick={() => setMLivreProntosOpen((prev) => !prev)}
                      aria-expanded={showMLivreProntosOpen}
                      className="w-full min-h-[48px] px-4 py-3 flex items-center justify-between text-sm font-bold text-slate-800 hover:bg-slate-50 cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        {showMLivreProntosOpen ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                        Prontos
                      </span>
                      <span className="font-mono-num text-xs font-bold">{prontosMLivre.length}</span>
                    </button>
                    {showMLivreProntosOpen && (
                      <div className="p-3 pt-1 border-t border-slate-100 space-y-3">
                        {prontosMLivrePorDia.length ? (
                          prontosMLivrePorDia.map(([dia, pedidosDoDia], index) => (
                            <details key={dia} open={index === 0} className="relative bg-white border border-slate-200 rounded-lg overflow-hidden">
                              <summary className="min-h-[44px] px-3 pr-12 py-2 flex items-center justify-between gap-3 text-sm font-bold text-slate-700 cursor-pointer list-none">
                                <span>{dia.split('-').reverse().join('/')}</span>
                                <span className="font-mono-num text-xs">{pedidosDoDia.length}</span>
                              </summary>
                              {role === 'lancamento' && <button
                                type="button"
                                aria-label={`Apagar todos os pedidos prontos de ${dia.split('-').reverse().join('/')}`}
                                title="Apagar todos os pedidos prontos deste dia"
                                onClick={() => setPendingDeleteMLivreDay(dia)}
                                className="absolute top-1.5 right-1.5 w-8 h-8 inline-flex items-center justify-center rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-100"
                              >
                                <X className="w-4 h-4" />
                              </button>}
                              <div className="p-3 pt-1 border-t border-slate-100 space-y-3">
                                {pedidosDoDia.map((p) => (
                                  <OrderCard
                                    key={p.id}
                                    pedido={p}
                                    canEdit={role === 'lancamento'}
                                    onEdit={handleEditPedido}
                                    onDuplicate={handleDuplicatePedido}
                                    onPdf={handlePdfPedido}
                                    onDelete={setPendingDeleteId}
                                  />
                                ))}
                              </div>
                            </details>
                          ))
                        ) : (
                          <p className="text-center text-sm text-slate-500 py-4">
                            Nenhum pedido M.Livre pronto.
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </section>
              )}
            </>
          )}

          {/* Role: Fábrica */}
          {role === 'fabrica' && (activeTab === 'fabrica' || activeTab === 'fabrica-mlivre') && (
            <FactoryView
              pedidos={pedidos}
              mLivreMode={activeTab === 'fabrica-mlivre'}
              onAtualizar={atualizarPedidos}
              atualizando={atualizandoMLivre}
              onImprimir={(lista) => handlePdfFactory(lista, activeTab === 'fabrica-mlivre')}
              onToggleItem={handleToggleFactoryItem}
              onConfirmOrderReady={handleConfirmOrderReady}
            />
          )}
        </main>

        <PdfPreviewModal
          open={Boolean(pdfPreview)}
          pedidos={pdfPreview?.pedidos || []}
          titulo={pdfPreview?.titulo || ''}
          emittedAt={pdfPreview?.emittedAt}
          onClose={() => setPdfPreview(null)}
          onPrint={() => {
            if (!pdfPreview) return;
            setPrintData(pdfPreview);
            setPrintRequestId((c) => c + 1);
          }}
        />
      </div>

      {/* Confirmation Dialogs */}
      <ConfirmLaunchDialog
        open={Boolean(pendingLaunch)}
        cliente={pendingLaunch?.cliente || ''}
        mLivre={Boolean(pendingLaunch?.mLivre)}
        dataEntrada={pendingLaunch?.dataEntrada || ''}
        pretensaoEntrega={pendingLaunch?.pretensaoEntrega || ''}
        entregaMLivreHora={pendingLaunch?.entregaMLivreHora || ''}
        urgente={Boolean(pendingLaunch?.urgente)}
        itens={pendingLaunch?.itens || []}
        obs={pendingLaunch?.obs || ''}
        saving={savingOrder}
        onCancel={() => setPendingLaunch(null)}
        onConfirm={handleConfirmLaunch}
      />

      <SimpleConfirmDialog
        open={Boolean(pendingDeleteMLivreDay)}
        title="Apagar pedidos prontos do dia"
        message={`Deseja apagar todos os ${allPedidos.filter((p) => p.mLivre && p.pronto && !p.entregue && dataEntradaDoPedido(p) === pendingDeleteMLivreDay).length} pedidos prontos de ${pendingDeleteMLivreDay ? pendingDeleteMLivreDay.split('-').reverse().join('/') : ''}? Esta ação não pode ser desfeita.`}
        confirmLabel="Apagar pedidos do dia"
        confirmVariant="danger"
        busy={deletingOrder}
        onCancel={() => setPendingDeleteMLivreDay(null)}
        onConfirm={handleDeleteMLivreDayConfirm}
      />

      <SimpleConfirmDialog
        open={Boolean(pendingDeleteId)}
        title="Confirmar exclusão"
        message={`Deseja apagar o pedido de ${pendingDeletePedido?.cliente || 'cliente'}? Esta ação não pode ser desfeita.`}
        confirmLabel="Apagar pedido"
        confirmVariant="danger"
        busy={deletingOrder}
        onCancel={() => setPendingDeleteId(null)}
        onConfirm={handleDeleteConfirm}
      />

      <SimpleConfirmDialog
        open={Boolean(pendingDeliverId)}
        title="Confirmar entrega"
        message={`Confirma que o pedido de ${pendingDeliverPedido?.cliente || 'cliente'} foi entregue?`}
        confirmLabel="Confirmar entrega"
        confirmVariant="success"
        busy={deliveringOrder}
        onCancel={() => setPendingDeliverId(null)}
        onConfirm={handleDeliverConfirm}
      />

      {/* Error Banner */}
      {appError && (
        <div
          role="alert"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-50 max-w-md w-[calc(100%-24px)] px-4 py-3 bg-red-50 border border-red-300 text-red-900 text-xs font-bold rounded-xl shadow-lg"
        >
          {appError}
        </div>
      )}

      {/* Real-time Toasts */}
      {toasts.length > 0 && (
        <div className="fixed right-4 bottom-4 z-50 space-y-2 max-w-sm w-[calc(100%-32px)]">
          {toasts.map((t) => (
            <div
              key={t.id}
              role="status"
              className="bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700"
            >
              <div className="text-xs font-bold">{t.title}</div>
              <div className="text-xs text-slate-300 mt-0.5">{t.body}</div>
            </div>
          ))}
        </div>
      )}

      {/* A4 Print Sheet */}
      <PrintSheet
        pedidos={printData.pedidos}
        titulo={printData.titulo}
        emittedAt={printData.emittedAt}
      />
    </>
  );
}
