export type UserRole = 'lancamento' | 'fabrica';

export type TabKey = 'pedidos' | 'fabrica' | 'mlivre' | 'fabrica-mlivre';

export type ItemTipo = 'estribo' | 'outro';

export type UnidadeOutro = 'un' | 'kg';

export type EmbalagemTipo = 'caixa' | 'pacote';

export type StatusFiltro = 'todos' | 'urgente' | 'produzindo' | 'pronto' | 'entregue';

export interface PedidoItem {
  tipo: ItemTipo;
  medida: string;
  material: string;
  qtd: number;
  pronto?: boolean;
  unidade?: UnidadeOutro;
  caixas?: number;
  naoCaixa?: boolean;
  codigo?: string;
  bitola?: string;
  embalagem?: EmbalagemTipo;
  unidadeLancamento?: 'caixa';
  caixaNumero?: number;
}

export interface Pedido {
  id: string;
  cliente: string;
  itens: PedidoItem[];
  estribosProntos: boolean[];
  criadoEm: number;
  dataEntrada: string;
  pretensaoEntrega: string;
  urgente: boolean;
  mLivre: boolean;
  entregaMLivre: string;
  mLivreVisto: boolean;
  mLivreVistoEm?: number;
  pronto: boolean;
  prontoEm?: number | null;
  entregue: boolean;
  entregueEm?: number | null;
  temEstribo?: boolean;
  obs: string;
  numeroPedido?: string;
  kg?: number;
  atualizadoEm?: number;
  atualizadoPor?: string;
  criadoPor?: string;
}

export type PedidoWritePayload = Omit<Pedido, 'id' | 'mLivre' | 'entregaMLivre' | 'mLivreVisto'> & {
  mLivre?: boolean;
  entregaMLivre?: string;
  mLivreVisto?: boolean;
};

export interface TelaSpec {
  codigo: string;
  medida: string;
  bitola: string;
}

export interface ToastNotice {
  id: string;
  title: string;
  body: string;
}
