import React, { useState } from 'react';
import { ArrowRight, Eye, EyeOff, Lock, Mail } from 'lucide-react';
import { signInUser } from '../firebase';

const LAST_EMAIL_KEY = 'estribos.lastEmail';

function readSavedEmail(): string {
  try {
    return localStorage.getItem(LAST_EMAIL_KEY) || '';
  } catch {
    return '';
  }
}

interface LoginScreenProps {
  externalError?: string;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ externalError }) => {
  const [savedInitialEmail] = useState(() => readSavedEmail());
  const [email, setEmail] = useState(savedInitialEmail);
  const [rememberEmail, setRememberEmail] = useState(() => Boolean(savedInitialEmail));
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState('');
  const [logoFailed, setLogoFailed] = useState(false);

  const mensagemErro = erro || externalError || '';

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const cleanEmail = email.trim();
    if (!cleanEmail || !senha) return;
    setErro('');
    setLoading(true);
    try {
      await signInUser(cleanEmail, senha);
      try {
        if (rememberEmail) {
          localStorage.setItem(LAST_EMAIL_KEY, cleanEmail);
        } else {
          localStorage.removeItem(LAST_EMAIL_KEY);
        }
      } catch {
        // Ignore storage quota errors
      }
    } catch (error: unknown) {
      const code = (error as { code?: string })?.code;
      if (
        code === 'auth/invalid-credential' ||
        code === 'auth/user-not-found' ||
        code === 'auth/wrong-password'
      ) {
        setErro('E-mail ou senha incorretos.');
      } else {
        setErro('Não foi possível entrar. Verifique seus dados e a conexão.');
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen flex flex-col bg-[#090d14] text-slate-100">
      {/* Subtle dark steel ambient radial lighting */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(220,38,38,0.10),transparent_48%),linear-gradient(to_bottom,#0b101b_0%,#070a10_100%)]"
      />

      {/* Top bar */}
      <header className="relative z-10 border-b border-slate-800/80 bg-[#0b101b]/90">
        <div className="max-w-5xl mx-auto px-4 sm:px-8 min-h-14 sm:h-16 py-2.5 sm:py-0 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            {!logoFailed && (
              <div className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg bg-white p-1 flex items-center justify-center shrink-0">
                <img
                  src="/logo-arames.png"
                  alt="Logo Arames Brasil"
                  onError={() => setLogoFailed(true)}
                  className="h-full w-full object-contain"
                />
              </div>
            )}
            <div className="min-w-0">
              <span className="block text-base sm:text-lg font-extrabold tracking-tight text-white whitespace-nowrap leading-tight">
                ARAMES <span className="text-red-500">BRASIL</span>
              </span>
              <span className="block sm:hidden font-mono-num text-[11px] font-medium text-slate-400">
                Controle de Pedidos
              </span>
            </div>
          </div>
          <span className="hidden sm:inline font-mono-num text-xs font-medium tracking-wide text-slate-400 whitespace-nowrap">
            Controle de Pedidos
          </span>
        </div>
      </header>

      {/* Main dark industrial centered panel */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-6 sm:px-8 sm:py-14">
        <div className="w-full max-w-[440px]">
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 sm:p-9">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1.5">
                <label
                  htmlFor="loginEmail"
                  className="block text-xs font-semibold tracking-wide text-slate-200"
                >
                  E-mail
                </label>
                <div className="relative">
                  <Mail
                    aria-hidden="true"
                    className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                  />
                  <input
                    id="loginEmail"
                    type="email"
                    autoComplete="username"
                    autoCapitalize="none"
                    spellCheck={false}
                    placeholder="setor@aramesbrasil.com.br"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full min-h-[48px] pl-10 pr-3.5 py-2.5 text-sm bg-[#090d14] border border-slate-700 rounded-lg text-slate-100 placeholder:text-slate-500 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500/30 focus:border-red-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="loginSenha"
                  className="block text-xs font-semibold tracking-wide text-slate-200"
                >
                  Senha
                </label>
                <div className="relative">
                  <Lock
                    aria-hidden="true"
                    className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                  />
                  <input
                    id="loginSenha"
                    type={mostrarSenha ? 'text' : 'password'}
                    autoComplete="current-password"
                    autoCapitalize="off"
                    placeholder="Digite sua senha"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    required
                    className="w-full min-h-[48px] pl-10 pr-12 py-2.5 text-sm bg-[#090d14] border border-slate-700 rounded-lg text-slate-100 placeholder:text-slate-500 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500/30 focus:border-red-500"
                  />
                  <button
                    type="button"
                    onClick={() => setMostrarSenha((prev) => !prev)}
                    aria-label={mostrarSenha ? 'Ocultar senha' : 'Ver senha'}
                    className="absolute right-1.5 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center text-slate-400 hover:text-white rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 cursor-pointer"
                  >
                    {mostrarSenha ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-0.5">
                <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-300 cursor-pointer select-none min-h-[36px]">
                  <input
                    type="checkbox"
                    checked={rememberEmail}
                    onChange={(e) => setRememberEmail(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-600 bg-[#090d14] text-red-600 focus:ring-red-500 accent-red-600 cursor-pointer"
                  />
                  <span>Lembrar e-mail neste aparelho</span>
                </label>
              </div>

              {mensagemErro && (
                <p
                  role="alert"
                  className="text-xs font-semibold text-red-200 bg-red-950/60 border border-red-800/80 rounded-lg px-3.5 py-2.5"
                >
                  {mensagemErro}
                </p>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full min-h-[48px] px-5 py-3 inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 active:bg-red-700 disabled:opacity-60 text-white font-bold text-sm rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 focus-visible:ring-offset-[#111827] cursor-pointer"
              >
                <span>{loading ? 'Entrando...' : 'Entrar'}</span>
                {!loading && <ArrowRight className="w-4 h-4" aria-hidden="true" />}
              </button>
            </form>
          </div>
        </div>
      </main>

      {/* Quiet dark footer */}
      <footer className="relative z-10 border-t border-slate-800/80 bg-[#0b101b]/70">
        <div className="max-w-5xl mx-auto px-4 sm:px-8 min-h-12 py-3 sm:py-0 flex flex-col sm:flex-row items-center justify-between gap-1 sm:gap-4 text-xs text-slate-400 text-center sm:text-left">
          <span>Arames Brasil</span>
          <span className="font-mono-num">Lançamento · Fábrica · Expedição</span>
        </div>
      </footer>
    </div>
  );
};
